/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PesertaDidik, Rombel, GTK, Nilai, Pembelajaran, Absensi } from '../types';
import { X, Printer, Download, Award, Calendar, CheckCircle } from 'lucide-react';

interface ReportPdfProps {
  student: PesertaDidik;
  rombel: Rombel;
  gtkList: GTK[];
  pembelajaranList: Pembelajaran[];
  nilaiList: Nilai[];
  absensiList: Absensi[];
  semester: number;
  onClose: () => void;
}

export default function ReportPdf({
  student,
  rombel,
  gtkList,
  pembelajaranList,
  nilaiList,
  absensiList,
  semester,
  onClose
}: ReportPdfProps) {
  
  // Find Wali Kelas
  const waliKelas = gtkList.find(g => g.id === rombel.wali_kelas_id);
  // Find Kepala Sekolah
  const kepsek = gtkList.find(g => g.status_kepegawaian === 'PNS' && g.id === 'gtk-kepsek');

  // Filter pembelajaran for this student's rombel
  const rombelPembelajaran = pembelajaranList.filter(p => p.rombel_id === rombel.id);

  // Calculate scores per pembelajaran ID
  const mapelScores = rombelPembelajaran.map(pemb => {
    const studentGrades = nilaiList.filter(n => n.pd_id === student.id && n.pembelajaran_id === pemb.id && n.semester === semester);
    
    const harian = studentGrades.find(g => g.jenis === 'HARIAN')?.nilai_angka || 0;
    const uts = studentGrades.find(g => g.jenis === 'UTS')?.nilai_angka || 0;
    const uas = studentGrades.find(g => g.jenis === 'UAS')?.nilai_angka || 0;

    // Standard Indonesian weighted final grade formula: (2*Harian + UTS + UAS) / 4
    let finalScore = 0;
    if (harian || uts || uas) {
      finalScore = Math.round((harian * 2 + uts + uas) / (harian && uts && uas ? 4 : (harian ? 2 : 0) + (uts ? 1 : 0) + (uas ? 1 : 0)));
    } else {
      // Default fallback
      finalScore = 0;
    }

    let letter: 'A' | 'B' | 'C' | 'D' = 'D';
    let desc = '';
    
    if (finalScore >= 88) {
      letter = 'A';
      desc = `Sangat Baik, menunjukkan penguasaan materi yang prima pada seluruh kompetensi dasar mapel ${pemb.mapel}.`;
    } else if (finalScore >= 80) {
      letter = 'B';
      desc = `Baik, menunjukkan pemahaman materi yang mantap pada sebagian besar bab dalam mapel ${pemb.mapel}.`;
    } else if (finalScore >= 70) {
      letter = 'C';
      desc = `Cukup, menunjukkan pemahaman materi yang cukup memadai dan kompeten dalam mapel ${pemb.mapel}.`;
    } else {
      letter = 'D';
      desc = `Kurang kompeten, memerlukan bimbingan intensif dan latihan terstruktur untuk remedial mapel ${pemb.mapel}.`;
    }

    return {
      mapel: pemb.mapel,
      harian,
      uts,
      uas,
      finalScore,
      letter,
      desc
    };
  });

  // Calculate attendance ratios
  const studentAbsences = absensiList.filter(a => a.pd_id === student.id);
  const sakit = studentAbsences.filter(a => a.status === 'S').length;
  const izin = studentAbsences.filter(a => a.status === 'I').length;
  const alpa = studentAbsences.filter(a => a.status === 'A').length;
  const hadir = studentAbsences.filter(a => a.status === 'H').length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto font-sans">
      <div id="modal-container" className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Toolbar (hidden during print) */}
        <div className="bg-slate-100 px-6 py-4 border-b border-slate-200 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-800">
              E-Rapor Digital Dapodikdasmen
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-sm"
              type="button"
            >
              <Printer className="w-4 h-4" />
              Cetak Rapor (PDF)
            </button>
            <button
              onClick={onClose}
              className="p-1 px-2.5 bg-slate-200 hover:bg-slate-300 rounded-lg text-slate-600 hover:text-slate-800 transition-colors cursor-pointer text-xs font-bold flex items-center gap-1"
              type="button"
            >
              <X className="w-4 h-4" />
              Tutup
            </button>
          </div>
        </div>

        {/* Outer PDF Stage */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-50 flex justify-center">
          
          {/* Paper Content Wrapper */}
          <div 
            id="rapor-cetak-wrapper" 
            className="bg-white w-full max-w-[210mm] min-h-[297mm] p-6 sm:p-12 border border-slate-300 rounded shadow-sm text-slate-900 leading-normal print:p-0 print:border-none print:shadow-none"
          >
            {/* 1. KOP SURAT (Dinas KEMDIKBUD) */}
            <div className="flex items-center border-b-[3px] border-slate-900 pb-4 mb-6">
              {/* Kemdikbud Logo Indicator */}
              <div className="w-16 h-16 mr-4 bg-blue-900 text-white flex items-center justify-center font-bold text-lg rounded-full border-2 border-slate-900 flex-shrink-0">
                ⭐
              </div>
              <div className="flex-1 text-center pr-12">
                <h4 className="text-sm font-bold tracking-widest text-slate-800 leading-tight uppercase">
                  PEMERINTAH KABUPATEN BEKASI
                </h4>
                <h4 className="text-sm font-bold tracking-widest text-slate-800 leading-tight uppercase">
                  DINAS PENDIDIKAN NASIONAL
                </h4>
                <h2 className="text-xl font-extrabold tracking-wide text-blue-900 leading-snug uppercase">
                  SMP NEGERI 1 BOJONGKENYOT
                </h2>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                  NPSN: 20123456 | NSS: 201021404001 | Status: Terakreditasi A
                </p>
                <p className="text-[9px] text-slate-500 leading-none">
                  Jl. Raya Pendidikan No. 1, Bojongkenyot, Kab. Bekasi - Telp: (021) 8901234
                </p>
              </div>
            </div>

            <div className="text-center mb-6">
              <h3 className="text-md font-bold underline tracking-wide uppercase">
                LAPORAN HASIL BELAJAR PESERTA DIDIK
              </h3>
              <p className="text-xs font-semibold uppercase">
                SEMESTER {semester === 1 ? 'GANJIL (I)' : 'GENAP (II)'} TAHUN PELAJARAN 2025/2026
              </p>
            </div>

            {/* 2. IDENTITAS PESERTA DIDIK */}
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs mb-6 border-b border-slate-200 pb-4">
              <div className="grid grid-cols-3 gap-0.5">
                <span className="text-slate-500">Nama Lengkap</span>
                <span className="col-span-2">: <strong className="text-slate-900 font-semibold">{student.nama}</strong></span>
                
                <span className="text-slate-500">Nomor Induk Siswa (NISN)</span>
                <span className="col-span-2">: <span className="font-mono">{student.nisn}</span></span>

                <span className="text-slate-500">NIK Siswa</span>
                <span className="col-span-2">: <span className="font-mono">{student.nik}</span></span>
              </div>
              <div className="grid grid-cols-3 gap-0.5">
                <span className="text-slate-500">Kelas / Rombel</span>
                <span className="col-span-2">: <strong>{rombel.nama}</strong></span>

                <span className="text-slate-500">Tingkat Kurikulum</span>
                <span className="col-span-2">: {rombel.kurikulum === 'KURIKULUM_MERDEKA' ? 'Kurikulum Merdeka' : 'K-13'}</span>

                <span className="text-slate-500">Agama</span>
                <span className="col-span-2">: {student.agama}</span>
              </div>
            </div>

            {/* 3. CAPAIAN NILAI */}
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5 border-l-4 border-blue-600 pl-2">
              A. PENILAIAN PENGETAHUAN & KETERAMPILAN
            </h4>
            <table className="w-full text-xs text-left border-collapse border border-slate-400 mb-6" id="rapor-table-nilai">
              <thead>
                <tr className="bg-slate-50">
                  <th className="border border-slate-400 p-2 text-center w-8">No</th>
                  <th className="border border-slate-400 p-2">Mata Pelajaran</th>
                  <th className="border border-slate-400 p-2 text-center w-12">Harian</th>
                  <th className="border border-slate-400 p-2 text-center w-12">UTS</th>
                  <th className="border border-slate-400 p-2 text-center w-12">UAS</th>
                  <th className="border border-slate-400 p-2 text-center w-16 bg-blue-50/50">Akhir</th>
                  <th className="border border-slate-400 p-2 text-center w-12 bg-blue-50/50">Predikat</th>
                  <th className="border border-slate-400 p-2">Deskripsi Capaian Kompetensi</th>
                </tr>
              </thead>
              <tbody>
                {mapelScores.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="border border-slate-400 p-4 text-center text-slate-400 italic">
                      Belum ada pendaftaran pembelajaran atau nilai terinput untuk rombel kelas ini.
                    </td>
                  </tr>
                ) : (
                  mapelScores.map((ms, index) => (
                    <tr key={index} className="hover:bg-slate-50/40">
                      <td className="border border-slate-400 p-2 text-center">{index + 1}</td>
                      <td className="border border-slate-400 p-2 font-medium">{ms.mapel}</td>
                      <td className="border border-slate-400 p-2 text-center font-mono">{ms.harian || '-'}</td>
                      <td className="border border-slate-400 p-2 text-center font-mono">{ms.uts || '-'}</td>
                      <td className="border border-slate-400 p-2 text-center font-mono">{ms.uas || '-'}</td>
                      <td className="border border-slate-400 p-2 text-center font-bold text-blue-900 bg-blue-50/20 font-mono">{ms.finalScore || '-'}</td>
                      <td className="border border-slate-400 p-2 text-center font-bold bg-blue-50/20">{ms.letter || '-'}</td>
                      <td className="border border-slate-400 p-2 text-slate-600 text-[10px] leading-tight font-serif italic">
                        {ms.desc}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {/* Attendance & Attitude block */}
            <div className="grid grid-cols-2 gap-6 text-xs mb-8">
              {/* Absensi */}
              <div>
                <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2 border-l-4 border-blue-600 pl-2">
                  B. PRESENSI & KEHADIRAN (BULAN INI)
                </h4>
                <table className="w-full text-xs text-left border-collapse border border-slate-300">
                  <thead>
                    <tr className="bg-slate-50">
                      <th className="border border-slate-300 p-2 font-bold w-1/2">Keterangan</th>
                      <th className="border border-slate-300 p-2 text-center font-bold">Jumlah Hari</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-slate-300 p-2">Sakit (S)</td>
                      <td className="border border-slate-300 p-2 text-center font-semibold text-amber-600 font-mono">{sakit}</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-2">Izin (I)</td>
                      <td className="border border-slate-300 p-2 text-center font-semibold text-blue-600 font-mono">{izin}</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-2">Tanpa Keterangan / Alpa (A)</td>
                      <td className="border border-slate-300 p-2 text-center font-semibold text-rose-600 font-mono">{alpa}</td>
                    </tr>
                    <tr className="bg-emerald-50">
                      <td className="border border-slate-300 p-2 font-bold text-emerald-800">Hadir Aktif (H)</td>
                      <td className="border border-slate-300 p-2 text-center font-bold text-emerald-800 font-mono">{hadir}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Attitude / Character */}
              <div>
                <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2 border-l-4 border-blue-600 pl-2">
                  C. SIKAP & ATTITUDE SOSIAL
                </h4>
                <table className="w-full text-xs text-left border-collapse border border-slate-300">
                  <thead>
                    <tr className="bg-slate-50">
                      <th className="border border-slate-300 p-2 font-bold">Dimensi Pembentukan Karakter</th>
                      <th className="border border-slate-300 p-2 text-center font-bold w-12">Nilai</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-slate-300 p-2">Sikap Spiritual (Ketaatan beribadah, toleransi)</td>
                      <td className="border border-slate-300 p-2 text-center font-bold text-emerald-700">A</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-2">Sikap Sosial (Kedisiplinan, kejujuran, kerukunan)</td>
                      <td className="border border-slate-300 p-2 text-center font-bold text-emerald-700">B</td>
                    </tr>
                    <tr>
                      <td className="border border-slate-300 p-2">Gotong Royong & Mandiri (Kurikuler Project)</td>
                      <td className="border border-slate-300 p-2 text-center font-bold text-emerald-700">A</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Remarks */}
            <div className="border border-slate-300 rounded-lg p-3 text-xs text-slate-700 bg-slate-50 mb-10 leading-normal">
              <strong className="text-slate-800 block mb-1">Catatan Wali Kelas:</strong>
              <p className="italic text-slate-600">
                "Tetaplah bersemangat dalam mempelajari sains dan matematika, Nak! Kemampuan berpikir analitismu sudah sangat baik, kembangkan lagi keaktifanmu berkolaborasi di dalam rombel diskusi kelas."
              </p>
            </div>

            {/* SIGNATURES */}
            <div className="grid grid-cols-3 gap-4 text-xs text-center mt-12 print:mt-16 leading-relaxed">
              <div>
                <p>Mengetahui,</p>
                <p className="font-medium">Orang Tua / Wali Siswa</p>
                <div className="h-16"></div>
                <p className="font-bold underline">......................................</p>
              </div>
              <div>
                <p>Bekasi, 18 Juni 2026</p>
                <p className="font-medium">Wali Kelas {rombel.nama}</p>
                <div className="h-16 flex items-end justify-center">
                  <span className="text-[10px] text-emerald-600 font-mono uppercase tracking-widest border border-emerald-300 px-1 bg-emerald-50 rounded select-none opacity-40">
                    E-SIGNED
                  </span>
                </div>
                <p className="font-bold underline">{waliKelas ? waliKelas.nama : 'Guru Pendamping'}</p>
                <p className="text-[10px] text-slate-400 font-mono">
                  {waliKelas?.nip ? `NIP. ${waliKelas.nip}` : 'GPP. Non PNS'}
                </p>
              </div>
              <div>
                <p>Mengetahui,</p>
                <p className="font-medium">Kepala Sekolah SMPN 1</p>
                <div className="h-16 flex items-end justify-center">
                  <span className="text-[10px] text-blue-600 font-mono uppercase tracking-widest border border-blue-300 px-1 bg-blue-50 rounded select-none opacity-40">
                    KOP SEKOLAH
                  </span>
                </div>
                <p className="font-bold underline">{kepsek ? kepsek.nama : 'Dr. H. Ahmad Fauzi, M.Pd.'}</p>
                <p className="text-[10px] text-slate-400 font-mono">
                  NIP. 197508122000031002
                </p>
              </div>
            </div>

            {/* Bottom mini seal indicator (print only) */}
            <div className="hidden print:flex justify-between items-center text-[8px] text-slate-400 mt-16 pt-3 border-t border-slate-100 font-mono">
              <span>Sistem Rapor Sekolah Digital Dapodikdasmen Kemdikbud RI • SMPN 1 Bojongkenyot</span>
              <span>Dokumen ini valid dan ditandatangani secara elektronik.</span>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
