/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { User, PesertaDidik, GTK, Rombel, Pembelajaran, Nilai, Absensi, JurnalMengajar, AuditLog } from '../types';
import { Calendar, BookOpen, Clock, AlertCircle, Save, CheckCircle, Award, ListFilter, Printer, ArrowRight, SaveAll } from 'lucide-react';
import ReportPdf from './ReportPdf';

interface GuruDashboardProps {
  currentUser: User;
  sekolah: any;
  pdList: PesertaDidik[];
  gtkList: GTK[];
  rombelList: Rombel[];
  pembelajaranList: Pembelajaran[];
  nilaiList: Nilai[];
  absensiList: Absensi[];
  jurnalList: JurnalMengajar[];
  onUpdateDb: (updatedDb: any) => void;
  onLogout: () => void;
}

export default function GuruDashboard({
  currentUser,
  sekolah,
  pdList,
  gtkList,
  rombelList,
  pembelajaranList,
  nilaiList,
  absensiList,
  jurnalList,
  onUpdateDb,
  onLogout
}: GuruDashboardProps) {
  
  // Tabs for Guru
  const [activeSubMenu, setActiveSubMenu] = useState<'INPUT_NILAI' | 'ABSENSI' | 'JURNAL' | 'REKAP'>('INPUT_NILAI');

  // Find exact GTK profile of current logged-in user
  const teacherProfile = useMemo(() => {
    return gtkList.find(g => g.user_id === currentUser.id);
  }, [gtkList, currentUser]);

  const teacherId = teacherProfile ? teacherProfile.id : 'gtk-guru2'; // fallback

  // Filter pembelajarans mapped directly to this teacher
  const myPembelajaran = useMemo(() => {
    return pembelajaranList.filter(p => p.guru_id === teacherId);
  }, [pembelajaranList, teacherId]);

  // Total teaching JP hours
  const totalJP = useMemo(() => {
    return myPembelajaran.reduce((acc, p) => acc + p.jam_mengajar, 0);
  }, [myPembelajaran]);

  // 1. INPUT GRADE STATE
  const [selectedPembelajaranId, setSelectedPembelajaranId] = useState(myPembelajaran[0]?.id || '');
  const activePembelajaran = useMemo(() => {
    return myPembelajaran.find(p => p.id === selectedPembelajaranId) || myPembelajaran[0];
  }, [myPembelajaran, selectedPembelajaranId]);

  // Students in active rombel
  const activeRombelStudents = useMemo(() => {
    if (!activePembelajaran) return [];
    return pdList.filter(p => p.rombel_id === activePembelajaran.rombel_id && p.status === 'AKTIF');
  }, [pdList, activePembelajaran]);

  // Intermediate state for student grades in selected Pembelajaran
  const [gradeDraft, setGradeDraft] = useState<{ [studentId: string]: { HARIAN: number; UTS: number; UAS: number } }>({});

  // Fetch or sync draft state whenever Pembelajaran changes
  useEffect(() => {
    if (!activePembelajaran) return;
    const initialDrafts: { [studentId: string]: { HARIAN: number; UTS: number; UAS: number } } = {};
    activeRombelStudents.forEach(st => {
      const gHarian = nilaiList.find(n => n.pd_id === st.id && n.pembelajaran_id === activePembelajaran.id && n.jenis === 'HARIAN')?.nilai_angka || 0;
      const gUts = nilaiList.find(n => n.pd_id === st.id && n.pembelajaran_id === activePembelajaran.id && n.jenis === 'UTS')?.nilai_angka || 0;
      const gUas = nilaiList.find(n => n.pd_id === st.id && n.pembelajaran_id === activePembelajaran.id && n.jenis === 'UAS')?.nilai_angka || 0;
      initialDrafts[st.id] = { HARIAN: gHarian, UTS: gUts, UAS: gUas };
    });
    setGradeDraft(initialDrafts);
  }, [activePembelajaran, activeRombelStudents, nilaiList]);

  // Handle cell text edits in grades grid
  const handleGradeChange = (studentId: string, jenis: 'HARIAN' | 'UTS' | 'UAS', val: string) => {
    const cleanNum = Math.min(100, Math.max(0, parseInt(val, 10) || 0));
    setGradeDraft(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [jenis]: cleanNum
      }
    }));
  };

  // Convert raw average score to Indonesian Kemdikbud standard letter A-D
  const computeFinalMetrics = (harian: number, uts: number, uas: number) => {
    // Weighted formula: (2 * Harian + UTS + UAS) / 4
    const avg = Math.round((harian * 2 + uts + uas) / 4);
    let letter: 'A' | 'B' | 'C' | 'D' = 'D';
    if (avg >= 88) letter = 'A';
    else if (avg >= 80) letter = 'B';
    else if (avg >= 70) letter = 'C';
    else letter = 'D';

    return { avg, letter };
  };

  // Bulk save grades to overall state
  const handleBulkSaveGrades = () => {
    if (!activePembelajaran) return;
    
    // Copy existing grades list
    let updatedNilai = [...nilaiList];
    const newLogs: AuditLog[] = [];

    activeRombelStudents.forEach(st => {
      const draft = gradeDraft[st.id] || { HARIAN: 0, UTS: 0, UAS: 0 };
      const categories: Array<'HARIAN' | 'UTS' | 'UAS'> = ['HARIAN', 'UTS', 'UAS'];
      
      categories.forEach(cat => {
        const val = draft[cat];
        const gradeId = `nil-${st.id}-${activePembelajaran.id}-${cat}`;
        
        let letter: 'A' | 'B' | 'C' | 'D' = 'D';
        const finalMetrics = computeFinalMetrics(draft.HARIAN, draft.UTS, draft.UAS);
        
        if (cat === 'UTS' || cat === 'UAS' || cat === 'HARIAN') {
          if (val >= 88) letter = 'A';
          else if (val >= 80) letter = 'B';
          else if (val >= 70) letter = 'C';
          else letter = 'D';
        }

        const existingIdx = updatedNilai.findIndex(n => n.id === gradeId);
        const newRecord: Nilai = {
          id: gradeId,
          pd_id: st.id,
          pembelajaran_id: activePembelajaran.id,
          jenis: cat,
          nilai_angka: val,
          nilai_huruf: letter,
          semester: 1
        };

        if (existingIdx !== -1) {
          updatedNilai[existingIdx] = newRecord;
        } else {
          updatedNilai.push(newRecord);
        }
      });
    });

    const l = {
      id: `log-${Date.now()}`,
      user_id: currentUser.id,
      username: currentUser.name,
      aksi: 'UPDATE' as const,
      tabel: 'Nilai',
      record_id: activePembelajaran.id,
      old_data: "[\"Penilaian Kelas Bulk Edit\"]",
      new_data: JSON.stringify(gradeDraft),
      created_at: new Date().toISOString()
    };
    
    onUpdateDb({
      nilaiList: updatedNilai,
      auditLogs: [l, ...jurnalList] // let's prepend audit log elegantly
    });

    alert("✓ Berhasil menyimpan rekapitulasi penilaian kelas!");
  };


  // 2. DAILY ATTENDANCE STATE
  const [selectedAttendanceRombelId, setSelectedAttendanceRombelId] = useState(rombelList[0]?.id || '');
  const activeAttendanceRombel = useMemo(() => {
    return rombelList.find(r => r.id === selectedAttendanceRombelId) || rombelList[0];
  }, [rombelList, selectedAttendanceRombelId]);

  const activeAttendanceStudents = useMemo(() => {
    if (!activeAttendanceRombel) return [];
    return pdList.filter(p => p.rombel_id === activeAttendanceRombel.id && p.status === 'AKTIF');
  }, [pdList, activeAttendanceRombel]);

  const [attendanceDate, setAttendanceDate] = useState(() => {
    const today = new Date();
    return today.toISOString().substring(0, 10);
  });

  // Radio button attendance draft
  const [attendanceDraft, setAttendanceDraft] = useState<{ [studentId: string]: 'H' | 'S' | 'I' | 'A' }>({});

  useEffect(() => {
    const freshDrafts: { [studentId: string]: 'H' | 'S' | 'I' | 'A' } = {};
    activeAttendanceStudents.forEach(st => {
      const match = absensiList.find(a => a.pd_id === st.id && a.tanggal === attendanceDate);
      freshDrafts[st.id] = match ? match.status : 'H'; // default Hadir
    });
    setAttendanceDraft(freshDrafts);
  }, [activeAttendanceRombel, activeAttendanceStudents, attendanceDate, absensiList]);

  const handleAttendanceRadio = (studentId: string, status: 'H' | 'S' | 'I' | 'A') => {
    setAttendanceDraft(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const handleBulkSaveAttendance = () => {
    let updatedAbsensi = [...absensiList];
    
    activeAttendanceStudents.forEach(st => {
      const status = attendanceDraft[st.id] || 'H';
      const absId = `abs-${st.id}-${attendanceDate}`;
      const existingIdx = updatedAbsensi.findIndex(a => a.id === absId);

      const record: Absensi = {
        id: absId,
        pd_id: st.id,
        tanggal: attendanceDate,
        status,
        keterangan: status === 'H' ? 'Masuk' : status === 'S' ? 'Sakit' : status === 'I' ? 'Izin' : 'Alpa'
      };

      if (existingIdx !== -1) {
        updatedAbsensi[existingIdx] = record;
      } else {
        updatedAbsensi.push(record);
      }
    });

    const l = {
      id: `log-${Date.now()}`,
      user_id: currentUser.id,
      username: currentUser.name,
      aksi: 'UPDATE' as const,
      tabel: 'Absensi',
      record_id: attendanceDate,
      old_data: "[\"Presensi Bulk\"]",
      new_data: JSON.stringify(attendanceDraft),
      created_at: new Date().toISOString()
    };

    onUpdateDb({ absensiList: updatedAbsensi, auditLogs: [l] });
    alert("✓ Presensi Harian Rombel Berhasil Disimpan!");
  };


  // 3. JURNAL MENGAJAR (EMIS GTK FORM WITH LOCALSTORAGE DRAFT AUTO-SAVE!)
  const [jTanggal, setJTanggal] = useState(() => new Date().toISOString().substring(0, 10));
  const [jJamKe, setJJamKe] = useState(1);
  const [jMateri, setJMateri] = useState('');
  const [jMetode, setJMetode] = useState('');
  const [jMedia, setJMedia] = useState('');
  const [jPenilaian, setJPenilaian] = useState('');

  // Draft auto-save mechanism
  useEffect(() => {
    const backup = localStorage.getItem(`jurnal_draft_${teacherId}`);
    if (backup) {
      try {
        const parsed = JSON.parse(backup);
        setJTanggal(parsed.tanggal || '');
        setJJamKe(parsed.jam_ke || 1);
        setJMateri(parsed.materi || '');
        setJMetode(parsed.metode || '');
        setJMedia(parsed.media || '');
        setJPenilaian(parsed.penilaian || '');
      } catch (e) {}
    }
  }, [teacherId]);

  const handleJurnalFieldChange = (field: string, value: any) => {
    if (field === 'tanggal') setJTanggal(value);
    if (field === 'jam_ke') setJJamKe(parseInt(value, 10));
    if (field === 'materi') setJMateri(value);
    if (field === 'metode') setJMetode(value);
    if (field === 'media') setJMedia(value);
    if (field === 'penilaian') setJPenilaian(value);

    // Auto save
    const currentDraft = {
      tanggal: field === 'tanggal' ? value : jTanggal,
      jam_ke: field === 'jam_ke' ? parseInt(value, 10) : jJamKe,
      materi: field === 'materi' ? value : jMateri,
      metode: field === 'metode' ? value : jMetode,
      media: field === 'media' ? value : jMedia,
      penilaian: field === 'penilaian' ? value : jPenilaian
    };
    localStorage.setItem(`jurnal_draft_${teacherId}`, JSON.stringify(currentDraft));
  };

  const handleSaveJurnalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jMateri.trim()) {
      alert("Materi pembelajaran wajib diisi!");
      return;
    }

    const newJurnal: JurnalMengajar = {
      id: `jur-${Date.now()}`,
      guru_id: teacherId,
      tanggal: jTanggal,
      materi: jMateri,
      metode: jMetode,
      jam_ke: jJamKe,
      media: jMedia,
      penilaian: jPenilaian
    };

    const updatedJurnalList = [newJurnal, ...jurnalList];
    onUpdateDb({ jurnalList: updatedJurnalList });

    // Clear draft
    localStorage.removeItem(`jurnal_draft_${teacherId}`);
    setJMateri('');
    setJMetode('');
    setJMedia('');
    setJPenilaian('');
    alert("✓ Jurnal EMIS GTK Berhasil Disimpan!");
  };


  // 4. PRINT REPORT STAGE
  const [selectedRekapRombelId, setSelectedRekapRombelId] = useState(rombelList[0]?.id || '');
  const activeRekapStudents = useMemo(() => {
    return pdList.filter(p => p.rombel_id === selectedRekapRombelId && p.status === 'AKTIF');
  }, [pdList, selectedRekapRombelId]);

  const [activeReportStudent, setActiveReportStudent] = useState<PesertaDidik | null>(null);

  return (
    <div className="flex flex-col min-h-screen bg-bg-base font-sans">
      
      {/* Header Bar */}
      <header className="bg-primary text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 font-sans">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 text-white rounded-xl border border-white/20">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-md font-extrabold tracking-wide text-white uppercase leading-none">PORTAL GURU SEBELUM EMIS</h2>
              <p className="text-[10px] text-white/80 mt-1">
                {sekolah.nama} • {teacherProfile ? teacherProfile.nama : 'Pendidik / Guru'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 font-sans">
            <span className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-white/10 border border-white/10 px-3 py-1 text-xs text-white font-mono">
              NUPTK: {teacherProfile?.nuptk || '-'}
            </span>
            <button
              onClick={onLogout}
              className="px-3.5 py-1.5 bg-red-800 hover:bg-red-900 border border-red-700 hover:border-red-800 text-white rounded-lg text-xs font-semibold select-none cursor-pointer transition-all"
            >
              Keluar / Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Pane */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col gap-6">
        
        {/* Row of counter cards */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="guru-dashboard-overview">
          <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex items-center justify-between relative overflow-hidden">
            <div className="absolute right-3 top-3 opacity-10 font-bold font-mono text-5xl">JP</div>
            <div>
              <p className="text-text-muted text-xs uppercase font-semibold">Beban Mengajar</p>
              <h3 className="text-2xl font-extrabold text-primary mt-1">{totalJP} <span className="text-xs font-normal text-text-muted">Jam Per Pekan</span></h3>
            </div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex items-center justify-between">
            <div>
              <p className="text-text-muted text-xs uppercase font-semibold">Kelas Dibina (Rombel)</p>
              <h3 className="text-2xl font-extrabold text-primary mt-1">{myPembelajaran.length} <span className="text-xs font-normal text-text-muted">Rombongan Belajar</span></h3>
            </div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex items-center justify-between bg-emerald-50 border-emerald-100 text-emerald-800">
            <div>
              <p className="text-emerald-600/80 text-xs uppercase font-semibold">Status Sync Dapodik</p>
              <h3 className="text-sm font-extrabold text-emerald-700 mt-1">✓ Sinkronisasi Pusdatin Terbaru Selesai</h3>
            </div>
          </div>
        </section>

        {/* Dashboard Tab Bar */}
        <section className="flex border-b border-border">
          <button
            onClick={() => setActiveSubMenu('INPUT_NILAI')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeSubMenu === 'INPUT_NILAI' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            📊 Isi & UTS / UAS Sederhana
          </button>
          
          <button
            onClick={() => setActiveSubMenu('ABSENSI')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeSubMenu === 'ABSENSI' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            📅 Absensi Siswa Harian
          </button>
          
          <button
            onClick={() => setActiveSubMenu('JURNAL')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeSubMenu === 'JURNAL' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            ✏️ Jurnal Mengajar EMIS GTK
          </button>

          <button
            onClick={() => setActiveSubMenu('REKAP')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeSubMenu === 'REKAP' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            🖨️ Cetak Rapor Digital Siswa
          </button>
        </section>


        {/* SUBMENU 1: INPUT NILAI */}
        {activeSubMenu === 'INPUT_NILAI' && (
          <div className="space-y-6">
            
            {/* Pembelajaran Selector bar */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-3 justify-between">
              <div className="flex items-center gap-2">
                <ListFilter className="w-4 h-4 text-slate-400" />
                <span className="text-xs font-bold text-slate-700">Pilih Jadwal Mengajar:</span>
                <select
                  value={selectedPembelajaranId}
                  onChange={(e) => setSelectedPembelajaranId(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
                >
                  {myPembelajaran.map(p => {
                    const r = rombelList.find(item => item.id === p.rombel_id);
                    return (
                      <option key={p.id} value={p.id}>{p.mapel} - {r?.nama || 'Rombel'}</option>
                    );
                  })}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-1 rounded font-mono border border-amber-200/50">
                  Formula Rapor Ganjil: (2 * Harian + UTS + UAS) / 4
                </span>
                <button
                  onClick={handleBulkSaveGrades}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-primary hover:bg-primary-hover text-white rounded-lg text-xs font-bold cursor-pointer transition-colors"
                >
                  <SaveAll className="w-4 h-4" />
                  Simpan Semua Nilai (Bulk Save)
                </button>
              </div>
            </div>

            {/* Grades Grid Table */}
            <div className="bg-white rounded-xl border border-border shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse text-text-main">
                  <thead className="bg-[#F8FAFC] border-b border-border uppercase text-[10px] tracking-wider text-text-muted font-bold font-mono">
                    <tr>
                      <th className="p-3 w-32">NISN</th>
                      <th className="p-3">Nama Lengkap Siswa</th>
                      <th className="p-3 text-center w-28">Nilai Harian (H)</th>
                      <th className="p-3 text-center w-28">Skor UTS</th>
                      <th className="p-3 text-center w-28">Skor UAS</th>
                      <th className="p-3 text-center w-28 bg-accent/50 text-primary font-bold">Rata-Rata Akhir</th>
                      <th className="p-3 text-center w-24 bg-accent/50 text-primary font-bold">Predikat</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeRombelStudents.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-10 text-center text-slate-400 italic">
                          Tidak ada siswa terdaftar dalam rombel ini, atau kelas mengajar kosong.
                        </td>
                      </tr>
                    ) : (
                      activeRombelStudents.map(st => {
                        const draft = gradeDraft[st.id] || { HARIAN: 0, UTS: 0, UAS: 0 };
                        const finalMetrics = computeFinalMetrics(draft.HARIAN, draft.UTS, draft.UAS);
                        
                        return (
                          <tr key={st.id} className="border-b border-slate-100 hover:bg-slate-50/30">
                            <td className="p-3 font-mono font-semibold text-slate-500">{st.nisn}</td>
                            <td className="p-3 font-bold text-slate-900">{st.nama}</td>
                            
                            <td className="p-3 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={draft.HARIAN}
                                onChange={(e) => handleGradeChange(st.id, 'HARIAN', e.target.value)}
                                className="block w-20 mx-auto text-center border border-border rounded px-1 py-1 font-mono hover:border-text-muted focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none"
                              />
                            </td>

                            <td className="p-3 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={draft.UTS}
                                onChange={(e) => handleGradeChange(st.id, 'UTS', e.target.value)}
                                className="block w-20 mx-auto text-center border border-border rounded px-1 py-1 font-mono hover:border-text-muted focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none"
                              />
                            </td>

                            <td className="p-3 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={draft.UAS}
                                onChange={(e) => handleGradeChange(st.id, 'UAS', e.target.value)}
                                className="block w-20 mx-auto text-center border border-border rounded px-1 py-1 font-mono hover:border-text-muted focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none"
                              />
                            </td>

                            <td className="p-3 text-center font-extrabold text-primary bg-accent/10 font-mono text-sm leading-none">
                              {finalMetrics.avg}
                            </td>

                            <td className="p-3 text-center font-black bg-accent/10">
                              <span className={`px-2 py-0.5 rounded text-xs ${
                                finalMetrics.letter === 'A' ? 'bg-emerald-50 text-emerald-700' :
                                finalMetrics.letter === 'B' ? 'bg-accent text-primary' :
                                finalMetrics.letter === 'C' ? 'bg-amber-50 text-amber-700' :
                                'bg-rose-50 text-rose-700'
                              }`}>
                                {finalMetrics.letter}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* SUBMENU 2: ABSENSI HARIAN */}
        {activeSubMenu === 'ABSENSI' && (
          <div className="space-y-6">
            
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-3 justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-slate-700">Tanggal Kehadiran:</span>
                <input
                  type="date"
                  value={attendanceDate}
                  onChange={(e) => setAttendanceDate(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none font-mono cursor-pointer"
                />

                <span className="text-xs font-bold text-slate-700 ml-2">Pilih Rombel:</span>
                <select
                  value={selectedAttendanceRombelId}
                  onChange={(e) => setSelectedAttendanceRombelId(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
                >
                  {rombelList.map(r => (
                    <option key={r.id} value={r.id}>{r.nama}</option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleBulkSaveAttendance}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow"
              >
                <Save className="w-3.5 h-3.5" />
                Simpan Presensi Harian
              </button>
            </div>

            {/* Attendance Matrix Table */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse text-slate-700">
                  <thead className="bg-slate-50 border-b border-slate-200 uppercase text-[10px] tracking-wider text-slate-500 font-bold font-mono">
                    <tr>
                      <th className="p-3 w-32">NISN</th>
                      <th className="p-3">Nama Lengkap Siswa</th>
                      <th className="p-3 text-center">Masuk / Hadir (H)</th>
                      <th className="p-3 text-center">Sakit (S)</th>
                      <th className="p-3 text-center">Izin Resmi (I)</th>
                      <th className="p-3 text-center">Alpa (A)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeAttendanceStudents.map(st => {
                      const currentStatus = attendanceDraft[st.id] || 'H';
                      return (
                        <tr key={st.id} className="border-b border-slate-100 hover:bg-slate-50/20">
                          <td className="p-3 font-mono text-slate-500">{st.nisn}</td>
                          <td className="p-3 font-semibold text-slate-900">{st.nama}</td>
                          
                          {/* Hadir radio */}
                          <td className="p-3 text-center">
                            <input
                              type="radio"
                              name={`att-${st.id}`}
                              checked={currentStatus === 'H'}
                              onChange={() => handleAttendanceRadio(st.id, 'H')}
                              className="w-4 h-4 text-emerald-600 bg-slate-100 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                            />
                          </td>

                          {/* Sakit radio */}
                          <td className="p-3 text-center">
                            <input
                              type="radio"
                              name={`att-${st.id}`}
                              checked={currentStatus === 'S'}
                              onChange={() => handleAttendanceRadio(st.id, 'S')}
                              className="w-4 h-4 text-amber-600 bg-slate-100 border-slate-300 focus:ring-amber-500 cursor-pointer"
                            />
                          </td>

                          {/* Izin radio */}
                          <td className="p-3 text-center">
                            <input
                              type="radio"
                              name={`att-${st.id}`}
                              checked={currentStatus === 'I'}
                              onChange={() => handleAttendanceRadio(st.id, 'I')}
                              className="w-4 h-4 text-blue-600 bg-slate-100 border-slate-300 focus:ring-blue-500 cursor-pointer"
                            />
                          </td>

                          {/* Alpa radio */}
                          <td className="p-3 text-center">
                            <input
                              type="radio"
                              name={`att-${st.id}`}
                              checked={currentStatus === 'A'}
                              onChange={() => handleAttendanceRadio(st.id, 'A')}
                              className="w-4 h-4 text-rose-600 bg-slate-100 border-slate-300 focus:ring-rose-500 cursor-pointer"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* SUBMENU 3: JURNAL MENGAJAR (EMIS FIELD METRIC) */}
        {activeSubMenu === 'JURNAL' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Input Form Column */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm lg:col-span-1">
              <h4 className="font-extrabold text-blue-900 text-xs uppercase tracking-wider mb-4 border-l-4 border-blue-600 pl-2">
                Log EMIS GTK Jurnal Mengajar
              </h4>
              <form onSubmit={handleSaveJurnalSubmit} className="space-y-4 text-xs text-slate-700">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-500 font-semibold mb-1">Tanggal Kegiatan*</label>
                    <input
                      type="date"
                      required
                      value={jTanggal}
                      onChange={(e) => handleJurnalFieldChange('tanggal', e.target.value)}
                      className="block w-full border border-slate-200 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 font-semibold mb-1">Jam Mengajar*</label>
                    <select
                      value={jJamKe}
                      onChange={(e) => handleJurnalFieldChange('jam_ke', e.target.value)}
                      className="block w-full border border-slate-200 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8].map(h => (
                        <option key={h} value={h}>Jam ke-{h}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Materi Pembelajaran (Dapodik)*</label>
                  <textarea
                    required
                    placeholder="Contoh: Pembelahan Sel Meiosis dan Mitosis"
                    value={jMateri}
                    onChange={(e) => handleJurnalFieldChange('materi', e.target.value)}
                    className="block w-full border border-slate-200 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none h-16 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Metode Pengajaran (EMIS)*</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Praktikum Laboratorium & SGD"
                    value={jMetode}
                    onChange={(e) => handleJurnalFieldChange('metode', e.target.value)}
                    className="block w-full border border-slate-200 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Media Belajar Pendukung (EMIS)*</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Mikroskop, Slide Sel Preparat"
                    value={jMedia}
                    onChange={(e) => handleJurnalFieldChange('media', e.target.value)}
                    className="block w-full border border-slate-200 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Kategori Penilaian (EMIS)</label>
                  <input
                    type="text"
                    placeholder="Contoh: LKPD Laporan Gambar Pengamatan"
                    value={jPenilaian}
                    onChange={(e) => handleJurnalFieldChange('penilaian', e.target.value)}
                    className="block w-full border border-slate-200 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold transition-all cursor-pointer shadow text-center"
                >
                  Publish Jurnal EMIS GTK
                </button>

                <p className="text-[10px] text-amber-700 bg-amber-50 rounded p-2 text-center border border-amber-200/50">
                  ⚡ Autofit Auto-Save: Draft jurnal disimpan otomatis ke localStorage pendaftar saat Anda mengetik.
                </p>
              </form>
            </div>

            {/* List Activity Logs Column */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm lg:col-span-2 space-y-3 flex flex-col h-[520px]">
              <h4 className="font-extrabold text-blue-900 text-xs uppercase tracking-wider border-l-4 border-blue-600 pl-2">
                Jurnal Mengajar Terbitan EMIS GTK Terakhir
              </h4>
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
                {jurnalList.filter(j => j.guru_id === teacherId).map(j => (
                  <div key={j.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5 leading-normal relative">
                    <div className="absolute right-3 top-3 text-[10px] font-mono text-slate-400">Jam ke-{j.jam_ke}</div>
                    <p className="font-bold text-slate-800 text-sm">{j.materi}</p>
                    <p className="text-[10px] font-semibold text-blue-750 font-mono">📅 Pelaksanaan Tgl: {j.tanggal}</p>
                    <div className="grid grid-cols-3 gap-2 text-[10.5px] mt-1 text-slate-500 font-serif">
                      <p><strong>Metode:</strong> {j.metode}</p>
                      <p><strong>Media:</strong> {j.media}</p>
                      <p><strong>Evaluasi:</strong> {j.penilaian || '-'}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* SUBMENU 4: REKAP KELAS RAPOR STAGE */}
        {activeSubMenu === 'REKAP' && (
          <div className="space-y-6">
            
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-705">Pilih Rombel Dibawah Binaan:</span>
                <select
                  value={selectedRekapRombelId}
                  onChange={(e) => setSelectedRekapRombelId(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
                >
                  {rombelList.map(r => (
                    <option key={r.id} value={r.id}>{r.nama}</option>
                  ))}
                </select>
              </div>
              <p className="text-xs text-slate-500 font-mono">Bila mapel terisi, rapor digital siap diekspor massal.</p>
            </div>

            {/* List of active study rombel students */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden text-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-slate-705 border-collapse">
                  <thead className="bg-slate-50 text-slate-500 border-b border-slate-200 font-bold uppercase text-[9px] tracking-wider font-mono">
                    <tr>
                      <th className="p-3">NISN</th>
                      <th className="p-3">Siswa Nama</th>
                      <th className="p-3 text-center">L/P</th>
                      <th className="p-3">Wali Kelas</th>
                      <th className="p-3 text-center">Status Presensi</th>
                      <th className="p-3 text-right">Lembar Hasil Belajar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeRekapStudents.map(st => {
                      const activeRombel = rombelList.find(r => r.id === st.rombel_id);
                      return (
                        <tr key={st.id} className="border-b border-slate-100 hover:bg-slate-50/40">
                          <td className="p-3 font-mono font-bold text-slate-900">{st.nisn}</td>
                          <td className="p-3 font-semibold text-slate-800">{st.nama}</td>
                          <td className="p-3 text-center font-mono font-semibold text-slate-500">{st.jk}</td>
                          <td className="p-3">{activeRombel ?  activeRombel.nama : '-'}</td>
                          <td className="p-3 text-center">
                            <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-100 font-bold text-[9px]">aktif</span>
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => {
                                const matchedRombel = rombelList.find(r => r.id === st.rombel_id);
                                if (matchedRombel) {
                                  setActiveReportStudent(st);
                                }
                              }}
                              className="inline-flex items-center gap-1 bg-blue-50 border border-blue-200 text-blue-750 font-bold p-1 px-2.5 rounded hover:bg-blue-100 transition-colors pointer-events-auto cursor-pointer"
                              type="button"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              Lihat Rapor (PDF)
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* Rapor PDF Modal Loader */}
      {activeReportStudent && (
        <ReportPdf
          student={activeReportStudent}
          rombel={rombelList.find(r => r.id === activeReportStudent.rombel_id)!}
          gtkList={gtkList}
          pembelajaranList={pembelajaranList}
          nilaiList={nilaiList}
          absensiList={absensiList}
          semester={1}
          onClose={() => setActiveReportStudent(null)}
        />
      )}

    </div>
  );
}
