/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User } from '../types';
import { Shield, BookOpen, Key, Users, School, Sparkles } from 'lucide-react';

interface LoginProps {
  users: User[];
  students: any[];
  teachers: any[];
  onLoginSuccess: (user: User) => void;
}

export default function Login({ users, students, teachers, onLoginSuccess }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username.trim() || !password.trim()) {
      setError("Username dan password wajib diisi");
      return;
    }

    // Lookup user
    const matchedUser = users.find(u => u.username.trim() === username.trim() && u.password_hash === password.trim());

    if (matchedUser) {
      if (!matchedUser.is_active) {
        setError("Akun Anda dinonaktifkan oleh administrator");
        return;
      }
      onLoginSuccess(matchedUser);
    } else {
      // Check if it's a student NISN from complete 90-student database
      // If student is not in the users table yet but is in pdList, we can allow entry
      const matchedStudent = students.find(s => s.nisn === username.trim());
      if (matchedStudent && password === "siswa123") {
        const studentUser: User = {
          id: `usr-${matchedStudent.id}`,
          username: matchedStudent.nisn,
          password_hash: "siswa123",
          role: "MURID",
          is_active: true,
          name: matchedStudent.nama
        };
        onLoginSuccess(studentUser);
        return;
      }

      setError("Username atau password salah. Cek panduan login di bawah.");
    }
  };

  const handleShortcutLogin = (user: User) => {
    onLoginSuccess(user);
  };

  const getShortcutLabel = (role: string) => {
    switch (role) {
      case 'SUPER_ADMIN': return 'Super Admin';
      case 'OPERATOR_DAPODIK': return 'Operator Dapodik';
      case 'GURU': return 'Guru Mapel';
      case 'MURID': return 'Peserta Didik (Murid)';
      default: return role;
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'SUPER_ADMIN': return <Shield className="w-4 h-4 text-rose-600" />;
      case 'OPERATOR_DAPODIK': return <School className="w-4 h-4 text-blue-600" />;
      case 'GURU': return <BookOpen className="w-4 h-4 text-emerald-600" />;
      case 'MURID': return <Users className="w-4 h-4 text-purple-600" />;
      default: return <Key className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-bg-base flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* Kemdikbud Crest Simulation Header */}
        <div className="flex justify-center">
          <div className="relative p-3 bg-primary text-white rounded-xl shadow-md border-4 border-white">
            <School className="w-12 h-12" id="logo-icon" />
            <div className="absolute -top-1 -right-1 bg-amber-450 p-1 rounded-full text-primary shadow-sm animate-pulse">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
        <h2 className="mt-4 text-center text-2xl font-extrabold tracking-tight text-primary">
          DAPODIK HUB & EMIS
        </h2>
        <p className="mt-1 text-center text-sm text-text-muted">
          SMP Negeri 1 Bojongkenyot
        </p>
        <div className="mt-1.5 flex justify-center">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold text-primary ring-1 ring-inset ring-primary/10">
            Tahun Ajaran 2025/2026 Ganjil
          </span>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md mr-4 ml-4 sm:mr-auto sm:ml-auto">
        <div className="bg-white py-8 px-4 shadow-sm border border-border rounded-xl sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && (
              <div className="rounded-md bg-red-50 p-4 border border-red-200">
                <div className="flex">
                  <div className="ml-1 text-sm font-medium text-red-800">
                    {error}
                  </div>
                </div>
              </div>
            )}

            <div>
              <label htmlFor="username" className="block text-sm font-semibold text-text-main">
                NIP / NUPTK / NISN / Username
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <input
                  id="username"
                  name="username"
                  type="text"
                  required
                  placeholder="Masukkan nomor identitas"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full rounded-md border border-border px-3 py-2 text-text-main placeholder-text-muted focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary sm:text-sm"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-semibold text-text-main">
                Kata Sandi
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full rounded-md border border-border px-3 py-2 text-text-main placeholder-text-muted focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary sm:text-sm"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-primary px-3 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-primary-hover focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary transition-colors"
              >
                Masuk ke Dashboard
              </button>
            </div>
          </form>

          {/* Sandboxed Shortcuts for Testing Multi-Roles */}
          <div className="mt-8 border-t border-border pt-6">
            <h3 className="text-xs font-semibold text-text-muted uppercase tracking-wider text-center mb-4">
              Akses Cepat Penguji (Role RBAC Sandbox)
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {users.map((u) => {
                // Short name
                let displayName = u.name;
                if (u.role === 'SUPER_ADMIN') displayName = 'Super Admin';
                if (u.username === 'operator1') displayName = 'Operator 1';
                if (u.username === 'operator2') displayName = 'Operator 2';
                if (u.role === 'GURU') {
                  const teacher = teachers.find(t => t.user_id === u.id);
                  displayName = teacher ? teacher.nama.split(',')[0] : u.name;
                }

                return (
                  <button
                    key={u.id}
                    onClick={() => handleShortcutLogin(u)}
                    className="flex flex-col items-start p-2.5 bg-bg-base hover:bg-accent border border-border hover:border-primary rounded-lg text-left transition-colors cursor-pointer group"
                    type="button"
                  >
                    <div className="flex items-center gap-1.5 font-bold text-text-main group-hover:text-primary leading-tight">
                      {getRoleIcon(u.role)}
                      <span>{getShortcutLabel(u.role)}</span>
                    </div>
                    <div className="text-[10px] text-text-muted mt-1">
                      User: <strong className="font-mono">{u.username}</strong>
                    </div>
                    <div className="text-[10px] text-text-muted truncate w-full">
                      {displayName}
                    </div>
                  </button>
                );
              })}

              {/* Add Murid Shortcut explicitly */}
              <button
                onClick={() => {
                  const sampleStudent = students[0] || { nisn: "0121000001", nama: "Andy Saputra" };
                  const studentUser: User = {
                    id: `usr-${sampleStudent.id}`,
                    username: sampleStudent.nisn,
                    password_hash: "siswa123",
                    role: "MURID",
                    is_active: true,
                    name: sampleStudent.nama
                  };
                  onLoginSuccess(studentUser);
                }}
                className="flex flex-col items-start p-2.5 bg-bg-base hover:bg-accent border border-border hover:border-primary rounded-lg text-left transition-colors cursor-pointer group"
                type="button"
              >
                <div className="flex items-center gap-1.5 font-bold text-secondary leading-tight">
                  <Users className="w-4 h-4 text-secondary" />
                  <span>Siswa (Sample VIII-A)</span>
                </div>
                <div className="text-[10px] text-text-muted mt-1">
                  User: <strong className="font-mono">{students[0]?.nisn || "0121000001"}</strong>
                </div>
                <div className="text-[10px] text-text-muted truncate w-full">
                  {students[0]?.nama || "Siswa Pertama"}
                </div>
              </button>
            </div>
            
            <div className="mt-4 text-[10px] text-text-muted bg-accent p-2 rounded-lg border border-primary/10 leading-normal text-center">
              ⚠️ Sandi default adalah <strong className="font-mono text-primary font-bold">admin123</strong>, <strong className="font-mono text-primary font-bold">ops123</strong>, <strong className="font-mono text-primary font-bold">guru123</strong>, atau <strong className="font-mono text-primary font-bold">siswa123</strong>.
            </div>
          </div>


        </div>
      </div>
    </div>
  );
}
