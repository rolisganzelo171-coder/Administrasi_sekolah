/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { PesertaDidik, GTK, Rombel, User, AuditLog, ValidationError, Sekolah } from '../types';
import { 
  validateNIK, 
  validateNISN, 
  validateNUPTK, 
  scanDapodikErrors, 
  writeAuditLog, 
  exportDapodikXLSX, 
  downloadDapodikTemplateXLSX, 
  parseDapodikTemplateXLSX 
} from '../utils/dapodikUtils';
import { 
  Building, 
  Users, 
  BookOpen, 
  GraduationCap, 
  Search, 
  Plus, 
  Filter, 
  Download, 
  Upload, 
  AlertTriangle, 
  Activity, 
  RefreshCw, 
  Trash2, 
  Edit, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle,
  Database,
  FileSpreadsheet,
  X,
  UserCheck,
  Briefcase
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

interface OperatorDashboardProps {
  currentUser: User;
  sekolah: Sekolah;
  pdList: PesertaDidik[];
  gtkList: GTK[];
  rombelList: Rombel[];
  pembelajaranList: any[];
  nilaiList: any[];
  absensiList: any[];
  auditLogs: AuditLog[];
  onUpdateDb: (updatedDb: any) => void;
  onLogout: () => void;
}

export default function OperatorDashboard({
  currentUser,
  sekolah,
  pdList,
  gtkList,
  rombelList,
  pembelajaranList,
  nilaiList,
  absensiList,
  auditLogs,
  onUpdateDb,
  onLogout
}: OperatorDashboardProps) {
  
  // Tabs Navigation
  const [activeTab, setActiveTab] = useState<'SEKOLAH' | 'PD' | 'GTK' | 'ROMBEL' | 'AUDIT' | 'SINKRON'>('PD');

  // Sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // States for Student Data Filter & Page
  const [pdSearch, setPdSearch] = useState('');
  const [pdFilterRombel, setPdFilterRombel] = useState('ALL');
  const [pdFilterJK, setPdFilterJK] = useState('ALL');
  const [pdPage, setPdPage] = useState(1);
  const [pdSortField, setPdSortField] = useState<'nisn' | 'nama'>('nama');
  const [pdSortOrder, setPdSortOrder] = useState<'asc' | 'desc'>('asc');
  const pdItemsPerPage = 10;

  // States for Teacher Data Filter & Page
  const [gtkSearch, setGtkSearch] = useState('');
  const [gtkFilterStatus, setGtkFilterStatus] = useState('ALL');
  const [gtkPage, setGtkPage] = useState(1);
  const gtkItemsPerPage = 10;

  // Dialog / Edit Moda State
  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<PesertaDidik | null>(null); // Null means ADDing new student
  
  const [gtkModalOpen, setGtkModalOpen] = useState(false);
  const [editingGtk, setEditingGtk] = useState<GTK | null>(null);

  // Modal Student fields
  const [fNisn, setFNisn] = useState('');
  const [fNik, setFNik] = useState('');
  const [fNama, setFNama] = useState('');
  const [fJk, setFJk] = useState<'L' | 'P'>('L');
  const [fTglLahir, setFTglLahir] = useState('2012-01-01');
  const [fAgama, setFAgama] = useState('ISLAM');
  const [fNoKK, setFNoKK] = useState('');
  const [fNamaAyah, setFNamaAyah] = useState('');
  const [fNamaIbu, setFNamaIbu] = useState('');
  const [fAlamat, setFAlamat] = useState('');
  const [fRombelId, setFRombelId] = useState('');
  const [fStatus, setFStatus] = useState<'AKTIF' | 'LULUS' | 'MUTASI' | 'KELUAR'>('AKTIF');

  // Modal GTK fields
  const [gNuptk, setGNuptk] = useState('');
  const [gNik, setGNik] = useState('');
  const [gNip, setGNip] = useState('');
  const [gNama, setGNama] = useState('');
  const [gMapel, setGMapel] = useState('');
  const [gKepegawaian, setGKepegawaian] = useState<'PNS' | 'PPPK' | 'GTT' | 'HONORER'>('PNS');
  const [gGolongan, setGGolongan] = useState('III/a');
  const [gTmt, setGTmt] = useState('2020-01-01');

  // Excel Upload states
  const [importStatus, setImportStatus] = useState<{ successCount: number; errors: string[] } | null>(null);

  // Run live validation scan across active lists
  const validationErrors = useMemo(() => {
    return scanDapodikErrors(pdList, gtkList, rombelList);
  }, [pdList, gtkList, rombelList]);

  // Handle student create or edit save Action
  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();

    // Field-level check NIK format and length
    const checkNik = validateNIK(fNik);
    const checkNisn = validateNISN(fNisn);

    if (!checkNik.isValid) {
      alert(`Validasi NIK Gagal: ${checkNik.error}`);
      return;
    }
    if (!checkNisn.isValid) {
      alert(`Validasi NISN Gagal: ${checkNisn.error}`);
      return;
    }

    let updatedPDList = [...pdList];
    let workingLog: AuditLog;

    if (editingStudent) {
      // Edit Student logic
      const index = updatedPDList.findIndex(p => p.id === editingStudent.id);
      if (index !== -1) {
        const updatedStudent: PesertaDidik = {
          ...editingStudent,
          nisn: fNisn,
          nik: fNik,
          nama: fNama,
          jk: fJk,
          tgl_lahir: fTglLahir,
          agama: fAgama,
          no_kk: fNoKK,
          nama_ayah: fNamaAyah,
          nama_ibu: fNamaIbu,
          alamat: fAlamat,
          rombel_id: fRombelId,
          status: fStatus
        };
        updatedPDList[index] = updatedStudent;
        workingLog = writeAuditLog(currentUser.id, currentUser.name, 'UPDATE', 'PesertaDidik', editingStudent.id, editingStudent, updatedStudent);
        onUpdateDb({ pdList: updatedPDList, auditLogs: [workingLog, ...auditLogs] });
      }
    } else {
      // Add Student logic
      const newStudent: PesertaDidik = {
        id: `pd-${Date.now()}`,
        nisn: fNisn,
        nik: fNik,
        nama: fNama,
        jk: fJk,
        tgl_lahir: fTglLahir,
        agama: fAgama,
        no_kk: fNoKK,
        nama_ayah: fNamaAyah,
        nama_ibu: fNamaIbu,
        alamat: fAlamat,
        rombel_id: fRombelId,
        status: fStatus
      };
      
      // Auto-create User account for Student so they can log in
      const studentUser: User = {
        id: `usr-siswa-${Date.now()}`,
        username: fNisn,
        password_hash: "siswa123",
        role: "MURID",
        is_active: true,
        name: fNama
      };

      updatedPDList.push(newStudent);
      workingLog = writeAuditLog(currentUser.id, currentUser.name, 'CREATE', 'PesertaDidik', newStudent.id, null, newStudent);
      onUpdateDb({ 
        pdList: updatedPDList, 
        users: [...onGetUsersHook(), studentUser],
        auditLogs: [workingLog, ...auditLogs] 
      });
    }

    setStudentModalOpen(false);
    setEditingStudent(null);
  };

  // Helper to fetch current users state
  const onGetUsersHook = (): User[] => {
    try {
      const db = JSON.parse(localStorage.getItem('dapodik_db') || '{}');
      return db.users || [];
    } catch(e) {
      return [];
    }
  };

  const openEditStudentModal = (student: PesertaDidik) => {
    setEditingStudent(student);
    setFNisn(student.nisn);
    setFNik(student.nik);
    setFNama(student.nama);
    setFJk(student.jk);
    setFTglLahir(student.tgl_lahir);
    setFAgama(student.agama);
    setFNoKK(student.no_kk);
    setFNamaAyah(student.nama_ayah);
    setFNamaIbu(student.nama_ibu);
    setFAlamat(student.alamat);
    setFRombelId(student.rombel_id || rombelList[0]?.id || '');
    setFStatus(student.status);
    setStudentModalOpen(true);
  };

  const openAddStudentModal = () => {
    setEditingStudent(null);
    setFNisn('');
    setFNik('');
    setFNama('');
    setFJk('L');
    setFTglLahir('2012-01-01');
    setFAgama('ISLAM');
    setFNoKK('');
    setFNamaAyah('');
    setFNamaIbu('');
    setFAlamat('');
    setFRombelId(rombelList[0]?.id || '');
    setFStatus('AKTIF');
    setStudentModalOpen(true);
  };

  // Soft delete student: status changes to 'MUTASI' (instead of full erasure, preserving data integrity)
  const handleSoftDeleteStudent = (pd: PesertaDidik) => {
    const confirmation = window.confirm(`Apakah Anda yakin ingin melakukan mutasi (soft-delete) untuk siswa ${pd.nama}?`);
    if (!confirmation) return;

    const updated = pdList.map(item => {
      if (item.id === pd.id) {
        return { ...item, status: 'MUTASI' as any };
      }
      return item;
    });

    const l = writeAuditLog(currentUser.id, currentUser.name, 'DELETE', 'PesertaDidik', pd.id, pd, { ...pd, status: 'MUTASI' });
    onUpdateDb({ pdList: updated, auditLogs: [l, ...auditLogs] });
  };

  // GTK Add / Edit logic
  const handleSaveGtk = (e: React.FormEvent) => {
    e.preventDefault();

    const checkNik = validateNIK(gNik);
    if (!checkNik.isValid) {
      alert(`NIK Guru tidak valid: ${checkNik.error}`);
      return;
    }
    if (gNuptk) {
      const checkNuptk = validateNUPTK(gNuptk);
      if (!checkNuptk.isValid) {
        alert(`NUPTK Guru tidak valid: ${checkNuptk.error}`);
        return;
      }
    }

    let updatedGtkList = [...gtkList];
    let workingLog: AuditLog;

    if (editingGtk) {
      const index = updatedGtkList.findIndex(g => g.id === editingGtk.id);
      if (index !== -1) {
        const updated: GTK = {
          ...editingGtk,
          nuptk: gNuptk || null,
          nik: gNik,
          nip: gNip || null,
          nama: gNama,
          mapel_sertifikasi: gMapel,
          status_kepegawaian: gKepegawaian,
          golongan: gGolongan,
          tmt: gTmt
        };
        updatedGtkList[index] = updated;
        workingLog = writeAuditLog(currentUser.id, currentUser.name, 'UPDATE', 'GTK', editingGtk.id, editingGtk, updated);
        onUpdateDb({ gtkList: updatedGtkList, auditLogs: [workingLog, ...auditLogs] });
      }
    } else {
      // Add GTK
      const newGtkId = `gtk-${Date.now()}`;
      const newUsrId = `usr-guru-${Date.now()}`;

      const newGtk: GTK = {
        id: newGtkId,
        nuptk: gNuptk || null,
        nik: gNik,
        nip: gNip || null,
        nama: gNama,
        mapel_sertifikasi: gMapel,
        status_kepegawaian: gKepegawaian,
        golongan: gGolongan,
        tmt: gTmt,
        user_id: newUsrId
      };

      // Create credential account
      const newTeacherUser: User = {
        id: newUsrId,
        username: gNuptk || gNik, // fallback to NIK if no NUPTK
        password_hash: "guru123",
        role: "GURU",
        is_active: true,
        name: gNama
      };

      updatedGtkList.push(newGtk);
      workingLog = writeAuditLog(currentUser.id, currentUser.name, 'CREATE', 'GTK', newGtk.id, null, newGtk);
      
      onUpdateDb({
        gtkList: updatedGtkList,
        users: [...onGetUsersHook(), newTeacherUser],
        auditLogs: [workingLog, ...auditLogs]
      });
    }

    setGtkModalOpen(false);
    setEditingGtk(null);
  };

  const openEditGtkModal = (gtk: GTK) => {
    setEditingGtk(gtk);
    setGNuptk(gtk.nuptk || '');
    setGNik(gtk.nik);
    setGNip(gtk.nip || '');
    setGNama(gtk.nama);
    setGMapel(gtk.mapel_sertifikasi);
    setGKepegawaian(gtk.status_kepegawaian);
    setGGolongan(gtk.golongan);
    setGTmt(gtk.tmt);
    setGtkModalOpen(true);
  };

  const openAddGtkModal = () => {
    setEditingGtk(null);
    setGNuptk('');
    setGNik('');
    setGNip('');
    setGNama('');
    setGMapel('');
    setGKepegawaian('PNS');
    setGGolongan('III/a');
    setGTmt('2020-01-01');
    setGtkModalOpen(true);
  };

  // Sync Dapodik Trigger Simulator
  const handleTriggerSync = () => {
    setIsSyncing(true);
    setSyncMessage(null);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncMessage("Koneksi Berhasil! Seluruh 27 tabel data SMP Negeri 1 Bojongkenyot disinkronisasikan ke Server Pusdatin Kemdikbud JKT.");
      
      const log = writeAuditLog(
        currentUser.id, 
        currentUser.name, 
        'SYNC_DAPODIK', 
        'Dapodik', 
        sekolah.id, 
        { sync_status: 'STALE' }, 
        { sync_status: 'SYNCED_PUSDATIN_SUCCESS', timestamp: new Date().toISOString() }
      );
      onUpdateDb({ auditLogs: [log, ...auditLogs] });
    }, 2000); // 2 second spin
  };

  // Export Dapodik trigger
  const handleExportDapodik = () => {
    exportDapodikXLSX({
      sekolah,
      pdList,
      gtkList,
      rombelList,
      pembelajaranList,
      nilaiList,
      absensiList
    });
    
    const log = writeAuditLog(currentUser.id, currentUser.name, 'EXPORT_DAPODIK', 'Dapodik', sekolah.id, null, { action: 'EXPORT_ALL_27_SHEETS' });
    onUpdateDb({ auditLogs: [log, ...auditLogs] });
  };

  // Excel Dapodik template importer
  const handleImportExcelDapodik = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const result = await parseDapodikTemplateXLSX(file);
      if (result.success.length > 0) {
        const mergedPD = [...pdList, ...result.success];
        const log = writeAuditLog(
          currentUser.id, 
          currentUser.name, 
          'IMPORT_DAPODIK', 
          'PesertaDidik', 
          `imported-${Date.now()}`, 
          null, 
          { count: result.success.length }
        );
        onUpdateDb({ pdList: mergedPD, auditLogs: [log, ...auditLogs] });
        setImportStatus({ successCount: result.success.length, errors: result.failed });
      } else {
        setImportStatus({ successCount: 0, errors: ["Tidak ada data valid yang bisa diimpor. Periksa format header template."] });
      }
    } catch (err: any) {
      alert("Error parsing excel spreadsheet: " + err.message);
    }
  };

  // Filter & Search student compilation
  const sortedStudents = useMemo(() => {
    return [...pdList].sort((a, b) => {
      const fieldA = String(a[pdSortField]).toLowerCase();
      const fieldB = String(b[pdSortField]).toLowerCase();
      if (fieldA < fieldB) return pdSortOrder === 'asc' ? -1 : 1;
      if (fieldA > fieldB) return pdSortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [pdList, pdSortField, pdSortOrder]);

  const filteredStudents = useMemo(() => {
    return sortedStudents.filter(pd => {
      const searchMatch = pd.nama.toLowerCase().includes(pdSearch.toLowerCase()) || 
                          pd.nisn.includes(pdSearch) ||
                          pd.nik.includes(pdSearch);
      const rombelMatch = pdFilterRombel === 'ALL' || pd.rombel_id === pdFilterRombel;
      const jkMatch = pdFilterJK === 'ALL' || pd.jk === pdFilterJK;
      
      return searchMatch && rombelMatch && jkMatch;
    });
  }, [sortedStudents, pdSearch, pdFilterRombel, pdFilterJK]);

  const paginatedStudents = useMemo(() => {
    const startIdx = (pdPage - 1) * pdItemsPerPage;
    return filteredStudents.slice(startIdx, startIdx + pdItemsPerPage);
  }, [filteredStudents, pdPage]);

  const totalPdPages = Math.ceil(filteredStudents.length / pdItemsPerPage) || 1;

  // Filter & Search teacher compilation
  const filteredGTK = useMemo(() => {
    return gtkList.filter(gtk => {
      const searchMatch = gtk.nama.toLowerCase().includes(gtkSearch.toLowerCase()) || 
                          (gtk.nuptk && gtk.nuptk.includes(gtkSearch)) ||
                          gtk.nik.includes(gtkSearch);
      const kepegawaianMatch = gtkFilterStatus === 'ALL' || gtk.status_kepegawaian === gtkFilterStatus;
      
      return searchMatch && kepegawaianMatch;
    });
  }, [gtkList, gtkSearch, gtkFilterStatus]);

  const paginatedGTK = useMemo(() => {
    const startIdx = (gtkPage - 1) * gtkItemsPerPage;
    return filteredGTK.slice(startIdx, startIdx + gtkItemsPerPage);
  }, [filteredGTK, gtkPage]);

  const totalGtkPages = Math.ceil(filteredGTK.length / gtkItemsPerPage) || 1;

  // Graph Data Setup
  // Map students count per rombel
  const rombelChartData = useMemo(() => {
    return rombelList.map(rom => {
      const count = pdList.filter(p => p.rombel_id === rom.id).length;
      const countsMale = pdList.filter(p => p.rombel_id === rom.id && p.jk === 'L').length;
      const countsFemale = pdList.filter(p => p.rombel_id === rom.id && p.jk === 'P').length;
      return {
        name: rom.nama,
        Laki: countsMale,
        Perempuan: countsFemale,
        Total: count
      };
    });
  }, [rombelList, pdList]);

  const genderPieData = useMemo(() => {
    const male = pdList.filter(p => p.jk === 'L').length;
    const female = pdList.filter(p => p.jk === 'P').length;
    return [
      { name: 'Siswa Laki-laki', value: male },
      { name: 'Siswa Perempuan', value: female }
    ];
  }, [pdList]);

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-bg-base font-sans">
      
      {/* 1. Sidebar Panel */}
      <aside className="w-full lg:w-64 bg-primary text-white flex flex-col shrink-0 border-r border-white/10">
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-white text-primary rounded-lg">
              <Database className="w-5 h-5" id="logo-icon" />
            </div>
            <div>
              <h1 className="font-extrabold text-sm tracking-wide">DAPODIK ADMIN</h1>
              <p className="text-[10px] text-white/70">Portal Operator Dapodik</p>
            </div>
          </div>
        </div>

        {/* User context card */}
        <div className="p-4 border-b border-white/10 bg-black/10 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center font-bold text-primary">
              {currentUser.username[0].toUpperCase()}
            </div>
            <div>
              <p className="font-semibold truncate max-w-[140px] text-white">{currentUser.name}</p>
              <p className="text-[10px] text-white/80 font-semibold">{currentUser.role === 'SUPER_ADMIN' ? '👑 Super Admin' : '💻 Operator Dinas'}</p>
            </div>
          </div>
        </div>

        {/* Nav list */}
        <nav className="flex-1 p-3 space-y-1">
          <button
            onClick={() => setActiveTab('SEKOLAH')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all cursor-pointer ${
              activeTab === 'SEKOLAH' ? 'bg-primary-hover text-white font-semibold border-l-4 border-white pl-2' : 'text-white/80 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Building className="w-4 h-4" />
            Profil Sekolah
          </button>
          
          <button
            onClick={() => { setActiveTab('PD'); setPdPage(1); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all cursor-pointer ${
              activeTab === 'PD' ? 'bg-primary-hover text-white font-semibold border-l-4 border-white pl-2' : 'text-white/80 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            Data Peserta Didik (Siswa)
          </button>

          <button
            onClick={() => { setActiveTab('GTK'); setGtkPage(1); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all cursor-pointer ${
              activeTab === 'GTK' ? 'bg-primary-hover text-white font-semibold border-l-4 border-white pl-2' : 'text-white/80 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            Data Guru & GTK
          </button>

          <button
            onClick={() => setActiveTab('ROMBEL')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all cursor-pointer ${
              activeTab === 'ROMBEL' ? 'bg-primary-hover text-white font-semibold border-l-4 border-white pl-2' : 'text-white/80 hover:bg-white/10 hover:text-white'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            Rombongan Belajar (Rombel)
          </button>

          <button
            onClick={() => setActiveTab('SINKRON')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all cursor-pointer ${
              activeTab === 'SINKRON' ? 'bg-primary-hover text-white font-semibold border-l-4 border-white pl-2' : 'text-white/80 hover:bg-white/10 hover:text-white'
            }`}
          >
            <RefreshCw className="w-4 h-4" />
            Sinkronisasi Dapodik
          </button>

          <button
            onClick={() => setActiveTab('AUDIT')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all cursor-pointer ${
              activeTab === 'AUDIT' ? 'bg-primary-hover text-white font-semibold border-l-4 border-white pl-2' : 'text-white/80 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4" />
            Log Aktivitas & Audit
          </button>
        </nav>

        {/* Footer actions */}
        <div className="p-4 border-t border-white/10 bg-black/10 text-center">
          <button
            onClick={onLogout}
            className="w-full py-2 bg-white/10 hover:bg-red-800 border border-white/10 hover:border-red-700 text-white rounded-lg text-xs font-semibold select-none cursor-pointer tracking-wide transition-all"
          >
            Keluar Sistem / Logout
          </button>
        </div>
      </aside>

      {/* 2. Main Space Content */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
        
        {/* TOP METADATA BAR */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 pb-4 border-b border-border gap-4">
          <div>
            <h2 className="text-xl font-extrabold text-primary font-sans tracking-tight leading-none uppercase">
              {sekolah.nama}
            </h2>
            <p className="text-xs text-text-muted mt-1">
              NPSN: <span className="font-mono text-text-main font-semibold">{sekolah.npsn}</span> | Kepegawaian: {gtkList.length} GTK | Terdaftar: {pdList.length} Murid
            </p>
          </div>
          
          {/* Quick Stats Block with real-time active validations status */}
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold px-2.5 py-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              {validationErrors.length} Issue Dapodik
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-md bg-accent border border-primary/20 text-primary text-xs font-semibold px-2.5 py-1">
              TA: {sekolah.tahun_ajaran_aktif}
            </span>
          </div>
        </header>

        {/* TAB 1: PROFILE SEKOLAH */}
        {activeTab === 'SEKOLAH' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-widest mb-4">Profil Lembaga Pendidikan</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2.5">
                  <p><strong className="text-slate-500">Nama Sekolah:</strong> <span className="text-slate-800 font-semibold">{sekolah.nama}</span></p>
                  <p><strong className="text-slate-500">NPSN:</strong> <span className="font-mono text-slate-800">{sekolah.npsn}</span></p>
                  <p><strong className="text-slate-500">Alamat Lengkap:</strong> <span className="text-slate-700">{sekolah.alamat}</span></p>
                  <p><strong className="text-slate-500">ID Kecamatan Dapodik:</strong> <span className="font-mono text-slate-800">{sekolah.id_kecamatan_dapodik}</span></p>
                </div>
                <div className="space-y-2.5">
                  <p><strong className="text-slate-500">Tahun Ajaran Aktif:</strong> <span className="text-slate-800 font-bold">{sekolah.tahun_ajaran_aktif}</span></p>
                  <p><strong className="text-slate-500">Status Akreditasi:</strong> <span className="text-emerald-700 font-bold">Grade A (Pusdatin)</span></p>
                  <p><strong className="text-slate-500">Bentuk Pendidikan:</strong> <span className="text-slate-800">Sekolah Menengah Pertama (SMP)</span></p>
                  <p><strong className="text-slate-500">Penyelenggaraan:</strong> <span className="text-slate-800">Double Shift Pagi - Sore</span></p>
                </div>
              </div>
            </div>

            {/* School statistics charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Chart 1: Rombel populations */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-3">Distribusi Siswa per Rombongan Belajar</h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={rombelChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="Laki" fill="#3b82f6" name="Laki-laki" />
                      <Bar dataKey="Perempuan" fill="#f43f5e" name="Perempuan" />
                      <Bar dataKey="Total" fill="#1e293b" name="Total Murid" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chart 2: Total Genders */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-3">Rasio Gender Siswa (N=90)</h4>
                <div className="h-64 flex justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={genderPieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label
                      >
                        <Cell fill="#0088FE" />
                        <Cell fill="#FF8042" />
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PESERTA DIDIK (STUDENT DATA MANAGEMENT) */}
        {activeTab === 'PD' && (
          <div className="space-y-6">
            
            {/* Live Dapodikdasmen Validation Error Display */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="bg-slate-900 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2 text-white">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                  <h3 className="font-bold text-sm tracking-wide">
                    Saringan Validasi Dapodikdasmen (Real-time Scan)
                  </h3>
                </div>
              </div>
              <div className="p-4 max-h-48 overflow-y-auto space-y-1.5">
                {validationErrors.length === 0 ? (
                  <div className="text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center gap-2 text-xs">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Seluruh data Peserta Didik dan GTK telah 100% Valid sesuai standar checksum NIK Kemdikbud.</span>
                  </div>
                ) : (
                  validationErrors.map((err, i) => (
                    <div key={err.id} className="text-rose-800 bg-rose-50/70 border border-rose-200/50 rounded-lg p-3 text-xs flex items-start gap-2.5">
                      <span className="p-1 bg-rose-100 rounded text-rose-800 font-bold text-[9px] leading-tight flex-shrink-0">
                        {err.jenis_kesalahan}
                      </span>
                      <div className="flex-1 leading-normal">
                        <strong>{err.record_name}</strong> - {err.deskripsi}
                      </div>
                      <button 
                        onClick={() => {
                          if (err.tabel === 'PESERTA_DIDIK') {
                            const pd = pdList.find(p => p.id === err.record_id);
                            if (pd) openEditStudentModal(pd);
                          } else {
                            const gtk = gtkList.find(g => g.id === err.record_id);
                            if (gtk) openEditGtkModal(gtk);
                          }
                        }}
                        className="text-[10px] text-blue-600 hover:underline hover:text-blue-800 font-semibold flex-shrink-0 cursor-pointer"
                      >
                        Perbaiki Data
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Controls Toolbar */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              
              {/* Search & filters */}
              <div className="flex flex-wrap items-center gap-2.5 flex-1">
                <div className="relative flex-1 max-w-xs min-w-[180px]">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari Murid (NISN/Nama/NIK)..."
                    value={pdSearch}
                    onChange={(e) => { setPdSearch(e.target.value); setPdPage(1); }}
                    className="block w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:border-blue-500 focus:outline-none placeholder-slate-400 text-slate-800 font-sans"
                  />
                </div>

                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                  <Filter className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
                  <select
                    value={pdFilterRombel}
                    onChange={(e) => { setPdFilterRombel(e.target.value); setPdPage(1); }}
                    className="text-xs bg-white border border-slate-200 rounded-md px-2 py-1 focus:outline-none text-slate-700 cursor-pointer"
                  >
                    <option value="ALL">Semua Rombel</option>
                    {rombelList.map(r => (
                      <option key={r.id} value={r.id}>{r.nama}</option>
                    ))}
                  </select>
                  
                  <select
                    value={pdFilterJK}
                    onChange={(e) => { setPdFilterJK(e.target.value); setPdPage(1); }}
                    className="text-xs bg-white border border-slate-200 rounded-md px-2 py-1 focus:outline-none text-slate-700 cursor-pointer"
                  >
                    <option value="ALL">Semua Gender</option>
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons: Add, Export, Template etc. */}
              <div className="flex flex-wrap items-center gap-2 self-end md:self-auto">
                <button
                  type="button"
                  onClick={openAddStudentModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Siswa Baru
                </button>

                <button
                  type="button"
                  onClick={handleExportDapodik}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-colors"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  Ekspor Dapodik (.xlsx)
                </button>

                <button
                  type="button"
                  onClick={downloadDapodikTemplateXLSX}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                  title="Unduh Template Excel Pengisian Massal"
                >
                  <Download className="w-3.5 h-3.5" />
                  Unduh Template
                </button>

                {/* Import Excel Button Input wrapper */}
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-sm">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Impor Template</span>
                  <input
                    type="file"
                    accept=".xlsx, .xls"
                    className="hidden"
                    onChange={handleImportExcelDapodik}
                  />
                </label>
              </div>

            </div>

            {/* Import Status Alert banner */}
            {importStatus && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-xs">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-1.5 font-bold text-blue-800">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                    <span>Laporan Impor Massal Dapodik Selesai</span>
                  </div>
                  <button onClick={() => setImportStatus(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
                </div>
                <p className="text-blue-900 mb-1">✓ Berhasil mengimpor <strong>{importStatus.successCount}</strong> record siswa baru ke dalam database lokal.</p>
                {importStatus.errors.length > 0 && (
                  <div className="mt-2 text-rose-800 space-y-1">
                    <p className="font-semibold underline">Gagal Memproses Baris:</p>
                    <ul className="list-disc list-inside max-h-24 overflow-y-auto">
                      {importStatus.errors.map((e, idx) => <li key={idx}>{e}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Students Table */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse text-slate-700">
                  <thead className="bg-slate-50 border-b border-slate-200 uppercase text-[10px] tracking-wider text-slate-500 font-semibold font-mono">
                    <tr>
                      <th className="p-3">NISN</th>
                      <th className="p-3">Nama Lengkap</th>
                      <th className="p-3">NIK</th>
                      <th className="p-3 text-center">JK</th>
                      <th className="p-3">Rombel Kelas</th>
                      <th className="p-3">No. KK</th>
                      <th className="p-3">Alamat</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedStudents.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="p-8 text-center text-slate-400 italic">
                          Tidak menemukan data Peserta Didik yang sesuai filter pencarian.
                        </td>
                      </tr>
                    ) : (
                      paginatedStudents.map(pd => {
                        const r = rombelList.find(item => item.id === pd.rombel_id);
                        return (
                          <tr key={pd.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                            <td className="p-3 font-mono font-bold text-slate-900">{pd.nisn}</td>
                            <td className="p-3 font-medium text-slate-900">{pd.nama}</td>
                            <td className="p-3 font-mono text-slate-600">{pd.nik || <span className="text-amber-500 italic">kosong</span>}</td>
                            <td className="p-3 text-center">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                pd.jk === 'L' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                              }`}>
                                {pd.jk}
                              </span>
                            </td>
                            <td className="p-3 font-medium text-slate-700">{r ? r.nama : <span className="text-rose-500 font-bold font-mono">No Rombel</span>}</td>
                            <td className="p-3 font-mono text-slate-400">{pd.no_kk}</td>
                            <td className="p-3 truncate max-w-[140px]" title={pd.alamat}>{pd.alamat}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                                pd.status === 'AKTIF' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                                pd.status === 'MUTASI' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                                'bg-slate-100 text-slate-600'
                              }`}>
                                {pd.status}
                              </span>
                            </td>
                            <td className="p-3 text-right">
                              <div className="inline-flex gap-1">
                                <button
                                  onClick={() => openEditStudentModal(pd)}
                                  className="p-1 px-1.5 bg-slate-50 hover:bg-blue-50 text-slate-500 hover:text-blue-700 border border-slate-200 rounded cursor-pointer"
                                  title="Edit Siswa"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => handleSoftDeleteStudent(pd)}
                                  className="p-1 px-1.5 bg-slate-50 hover:bg-rose-50 text-slate-500 hover:text-rose-700 border border-slate-200 rounded cursor-pointer"
                                  title="Mutasi / Soft Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Paginate indicator */}
              <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                <span>
                  Menampilkan <strong>{filteredStudents.length > 0 ? (pdPage - 1) * pdItemsPerPage + 1 : 0}</strong> - <strong>{Math.min(pdPage * pdItemsPerPage, filteredStudents.length)}</strong> dari <strong>{filteredStudents.length}</strong> siswa
                </span>
                <div className="flex gap-1 items-center">
                  <button
                    onClick={() => setPdPage(p => Math.max(1, p - 1))}
                    disabled={pdPage === 1}
                    className="p-1.5 border border-slate-200 bg-white rounded hover:bg-slate-100 disabled:opacity-50 cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <span className="px-2">Halaman {pdPage} dari {totalPdPages}</span>
                  <button
                    onClick={() => setPdPage(p => Math.min(totalPdPages, p + 1))}
                    disabled={pdPage === totalPdPages}
                    className="p-1.5 border border-slate-200 bg-white rounded hover:bg-slate-100 disabled:opacity-50 cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: GTK List */}
        {activeTab === 'GTK' && (
          <div className="space-y-6">
            
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-2.5 flex-1">
                <div className="relative flex-1 max-w-xs">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari Guru (Nama/NUPTK/NIP)..."
                    value={gtkSearch}
                    onChange={(e) => { setGtkSearch(e.target.value); setGtkPage(1); }}
                    className="block w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:border-blue-500 focus:outline-none placeholder-slate-400 text-slate-800"
                  />
                </div>

                <select
                  value={gtkFilterStatus}
                  onChange={(e) => { setGtkFilterStatus(e.target.value); setGtkPage(1); }}
                  className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none text-slate-700 cursor-pointer"
                >
                  <option value="ALL">Semua Kepegawaian</option>
                  <option value="PNS">Pegawai Negeri Sipil (PNS)</option>
                  <option value="PPPK">Pegawai Pemerintah Perjanjian Kerja (PPPK)</option>
                  <option value="GTT">Guru Tidak Tetap (GTT)</option>
                  <option value="HONORER">Honorer Sekolah</option>
                </select>
              </div>

              <button
                type="button"
                onClick={openAddGtkModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Tambah GTK Baru
              </button>
            </div>

            {/* GTK Table view */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse text-slate-700">
                  <thead className="bg-slate-50 border-b border-slate-200 uppercase text-[10px] tracking-wider text-slate-500 font-semibold font-mono">
                    <tr>
                      <th className="p-3">NUPTK</th>
                      <th className="p-3">Nama GTK</th>
                      <th className="p-3">NIP</th>
                      <th className="p-3">Sertifikasi Mapel</th>
                      <th className="p-3">Status Pegawai</th>
                      <th className="p-3">Golongan</th>
                      <th className="p-3">TMT Tugas</th>
                      <th className="p-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedGTK.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-400 italic">
                          Tidak menemukan data GTK / Pendidik yang dicari.
                        </td>
                      </tr>
                    ) : (
                      paginatedGTK.map(gtk => (
                        <tr key={gtk.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                          <td className="p-3 font-mono font-bold text-slate-900">{gtk.nuptk || <span className="text-slate-400 italic">Belum Ada</span>}</td>
                          <td className="p-3 font-medium text-slate-900">{gtk.nama}</td>
                          <td className="p-3 font-mono text-slate-600">{gtk.nip || '-'}</td>
                          <td className="p-3 text-slate-800">{gtk.mapel_sertifikasi}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold border border-blue-100">
                              {gtk.status_kepegawaian}
                            </span>
                          </td>
                          <td className="p-3 font-mono text-slate-600">{gtk.golongan}</td>
                          <td className="p-3 font-mono text-slate-500">{gtk.tmt}</td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => openEditGtkModal(gtk)}
                              className="p-1 px-1.5 bg-slate-50 hover:bg-blue-50 text-slate-500 hover:text-blue-700 border border-slate-200 rounded cursor-pointer"
                              title="Edit Data GTK"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Paginate gtks */}
              <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                <span>
                  Menampilkan <strong>{filteredGTK.length > 0 ? (gtkPage - 1) * gtkItemsPerPage + 1 : 0}</strong> - <strong>{Math.min(gtkPage * gtkItemsPerPage, filteredGTK.length)}</strong> dari <strong>{filteredGTK.length}</strong> GTK
                </span>
                <div className="flex gap-1 items-center">
                  <button
                    onClick={() => setGtkPage(g => Math.max(1, g - 1))}
                    disabled={gtkPage === 1}
                    className="p-1.5 border border-slate-200 bg-white rounded hover:bg-slate-100 disabled:opacity-50 cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <span className="px-2">Halaman {gtkPage} dari {totalGtkPages}</span>
                  <button
                    onClick={() => setGtkPage(g => Math.min(totalGtkPages, g + 1))}
                    disabled={gtkPage === totalGtkPages}
                    className="p-1.5 border border-slate-200 bg-white rounded hover:bg-slate-100 disabled:opacity-50 cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 4: ROMBEL DAN KELAS */}
        {activeTab === 'ROMBEL' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {rombelList.map(rom => {
                const headTeacher = gtkList.find(g => g.id === rom.wali_kelas_id);
                const studentsNum = pdList.filter(p => p.rombel_id === rom.id).length;
                const subjects = pembelajaranList.filter(p => p.rombel_id === rom.id);
                
                return (
                  <div key={rom.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden flex flex-col">
                    <div className="absolute right-3 top-3 bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded text-[10px] font-mono border border-blue-200">
                      Tingkat {rom.tingkat}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-extrabold text-blue-900 text-lg uppercase leading-tight">{rom.nama}</h4>
                      <p className="text-[10px] text-slate-400 font-mono tracking-wider uppercase mt-0.5">
                        {rom.kurikulum === 'KURIKULUM_MERDEKA' ? 'Kurikulum Merdeka' : 'Kurikulum K13'}
                      </p>

                      <div className="mt-4 space-y-2 text-xs border-t border-slate-100 pt-3">
                        <p><strong className="text-slate-500">Wali Kelas:</strong> <span className="font-semibold text-slate-800">{headTeacher ? headTeacher.nama : 'Belum Ditunjuk'}</span></p>
                        <p><strong className="text-slate-500">Total Siswa:</strong> <span className="font-semibold text-slate-800">{studentsNum} Anak</span></p>
                        <p><strong className="text-slate-500">Mata Pelajaran Aktif:</strong> <span className="font-semibold text-slate-800">{subjects.length} Mapel</span></p>
                      </div>

                      {subjects.length > 0 && (
                        <div className="mt-3.5 p-2 bg-slate-50 rounded-lg text-slate-600 text-[10px]">
                          <strong className="text-slate-700">Dosen / Guru Ampu:</strong>
                          <div className="mt-1 space-y-0.5 max-h-24 overflow-y-auto">
                            {subjects.map(sub => {
                              const tg = gtkList.find(g => g.id === sub.guru_id);
                              return (
                                <div key={sub.id} className="flex justify-between border-b border-dashed border-slate-200/50 pb-0.5">
                                  <span>{sub.mapel}</span>
                                  <strong className="text-slate-700 truncate max-w-[120px]">{tg ? tg.nama.split(',')[0] : 'Guru'}</strong>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-4 pt-3.5 border-t border-slate-100 text-[10.5px] font-medium text-slate-400">
                      Tahun Pelajaran: {rom.tahun_ajaran}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 5: SINKRONISASI COUPLER */}
        {activeTab === 'SINKRON' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm text-center">
              <div className="flex justify-center mb-4">
                <div className={`p-4 rounded-full ${isSyncing ? 'bg-amber-100 text-amber-600 animate-spin' : 'bg-blue-100 text-blue-600'}`}>
                  <RefreshCw className="w-10 h-10" />
                </div>
              </div>
              <h3 className="text-lg font-bold text-slate-800">Sinkronisasi Server Pusdatin Dapodikdasmen</h3>
              <p className="text-slate-500 text-xs mt-1 max-w-md mx-auto leading-relaxed">
                Tindakan ini menyinkronkan data profil sekolah, rombongan belajar, data pendidik GTK, dan data peserta didik di SMP Negeri 1 Bojongkenyot ke portal pusat Kemdikbud via Web Service API.
              </p>

              {syncMessage && (
                <div className="mt-4 p-3.5 rounded-lg text-xs bg-emerald-50 text-emerald-800 border border-emerald-200 text-left font-serif">
                  <strong>✓ Laporan Sinkronisasi Berhasil:</strong>
                  <p className="mt-1">{syncMessage}</p>
                </div>
              )}

              <div className="mt-6 flex justify-center gap-3">
                <button
                  onClick={handleTriggerSync}
                  disabled={isSyncing}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-lg transition-all cursor-pointer shadow"
                >
                  {isSyncing ? 'Menghubungkan Pusdatin...' : 'Mulai Sinkronisasi Data'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: AUDIT LOGS */}
        {activeTab === 'AUDIT' && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-blue-900 text-sm tracking-wider uppercase">Log Audit & Rekaman Perubahan Data</h3>
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden text-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-slate-700 border-collapse">
                  <thead className="bg-slate-50 text-slate-500 border-b border-slate-200 font-bold uppercase text-[9px] tracking-wider font-mono">
                    <tr>
                      <th className="p-3.5">Timestamp</th>
                      <th className="p-3.5">Petugas / User</th>
                      <th className="p-3.5">Akademik Aksi</th>
                      <th className="p-3.5">Kategori / Tabel</th>
                      <th className="p-3.5">Record ID</th>
                      <th className="p-3.5">Data Lama (Sebelum)</th>
                      <th className="p-3.5">Data Baru (Sesudah)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {auditLogs.map(log => (
                      <tr key={log.id} className="border-b border-slate-100 hover:bg-slate-50/40 align-top">
                        <td className="p-3.5 font-mono text-slate-500 whitespace-nowrap">
                          {new Date(log.created_at).toLocaleString('id-ID')}
                        </td>
                        <td className="p-3.5 font-semibold text-slate-800">{log.username}</td>
                        <td className="p-3.5">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold font-mono border ${
                            log.aksi === 'CREATE' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                            log.aksi === 'UPDATE' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                            log.aksi === 'DELETE' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                            'bg-slate-100 text-slate-700 border-slate-200'
                          }`}>
                            {log.aksi}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-650 font-mono block tracking-tight">{log.tabel}</td>
                        <td className="p-3.5 font-mono font-bold text-slate-500">{log.record_id}</td>
                        <td className="p-3.5">
                          {log.old_data ? (
                            <pre className="text-[10px] bg-slate-150 p-2 max-h-24 overflow-auto rounded font-mono text-slate-500 whitespace-pre-wrap max-w-xs leading-normal">
                              {log.old_data}
                            </pre>
                          ) : (
                            <span className="text-slate-350 italic">Kosong/Baru</span>
                          )}
                        </td>
                        <td className="p-3.5">
                          {log.new_data ? (
                            <pre className="text-[10px] bg-slate-150 p-2 max-h-24 overflow-auto rounded font-mono text-slate-600 whitespace-pre-wrap max-w-xs leading-normal">
                              {log.new_data}
                            </pre>
                          ) : (
                            <span className="text-slate-350 italic">Dihapus</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* STUDENT DETAILS EDIT MODAL */}
      {studentModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col font-sans">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <h4 className="font-bold text-sm tracking-wide">
                {editingStudent ? `✏️ Editan Profil: ${editingStudent.nama}` : '📝 Registrasi Peserta Didik Baru'}
              </h4>
              <button onClick={() => setStudentModalOpen(false)} className="text-slate-400 hover:text-white cursor-pointer select-none">
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <form onSubmit={handleSaveStudent} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-slate-700">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">NISN (10 Digit)*</label>
                  <input
                    type="text"
                    required
                    maxLength={10}
                    placeholder="Contoh: 0134958671"
                    value={fNisn}
                    onChange={(e) => setFNisn(e.target.value.replace(/\D/g, ''))}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">NIK Siswa (16 Digit)*</label>
                  <input
                    type="text"
                    required
                    maxLength={16}
                    placeholder="Contoh: 3216021203000004"
                    value={fNik}
                    onChange={(e) => setFNik(e.target.value.replace(/\D/g, ''))}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1">Nama Lengkap Peserta Didik*</label>
                <input
                  type="text"
                  required
                  placeholder="Amelia Ramadhani"
                  value={fNama}
                  onChange={(e) => setFNama(e.target.value)}
                  className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-medium"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Jenis Kelamin*</label>
                  <select
                    value={fJk}
                    onChange={(e) => setFJk(e.target.value as any)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none cursor-pointer"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Tanggal Lahir*</label>
                  <input
                    type="date"
                    required
                    value={fTglLahir}
                    onChange={(e) => setFTglLahir(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Agama*</label>
                  <select
                    value={fAgama}
                    onChange={(e) => setFAgama(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
                  >
                    <option value="ISLAM">Islam</option>
                    <option value="PROTESTAN">Kristen Protestan</option>
                    <option value="KATOLIK">Katolik</option>
                    <option value="HINDU">Hindu</option>
                    <option value="BUDHA">Budha</option>
                    <option value="KONGHUCU">Konghucu</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Nomor Kartu Keluarga (KK)</label>
                  <input
                    type="text"
                    maxLength={16}
                    value={fNoKK}
                    onChange={(e) => setFNoKK(e.target.value.replace(/\D/g, ''))}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Rombongan Belajar (Rombel)*</label>
                  <select
                    value={fRombelId}
                    onChange={(e) => setFRombelId(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none cursor-pointer"
                  >
                    {rombelList.map(r => (
                      <option key={r.id} value={r.id}>{r.nama}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Nama Ayah Kandung</label>
                  <input
                    type="text"
                    value={fNamaAyah}
                    onChange={(e) => setFNamaAyah(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Nama Ibu Kandung</label>
                  <input
                    type="text"
                    value={fNamaIbu}
                    onChange={(e) => setFNamaIbu(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1">Alamat Tinggal Sesuai KK</label>
                <textarea
                  value={fAlamat}
                  onChange={(e) => setFAlamat(e.target.value)}
                  className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none h-12"
                />
              </div>

              {editingStudent && (
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Status Keaktifan Siswa</label>
                  <select
                    value={fStatus}
                    onChange={(e) => setFStatus(e.target.value as any)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none cursor-pointer"
                  >
                    <option value="AKTIF">Aktif Sekolah</option>
                    <option value="MUTASI">Mutasi Keluar</option>
                    <option value="LULUS">Lulus</option>
                    <option value="KELUAR">Dikeluarkan / Drop out</option>
                  </select>
                </div>
              )}

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setStudentModalOpen(false)}
                  className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold cursor-pointer"
                >
                  Simpan Data
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GTK EDIT MODAL */}
      {gtkModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col font-sans">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <h4 className="font-bold text-sm tracking-wide">
                {editingGtk ? `✏️ Editan Profil GTK: ${editingGtk.nama}` : '📝 Tambah GTK / Guru Baru'}
              </h4>
              <button onClick={() => setGtkModalOpen(false)} className="text-slate-400 hover:text-white cursor-pointer select-none">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveGtk} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-slate-700">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">NUPTK Guru (16 Digit)</label>
                  <input
                    type="text"
                    maxLength={16}
                    placeholder="Contoh: 1029384756102938"
                    value={gNuptk}
                    onChange={(e) => setGNuptk(e.target.value.replace(/\D/g, ''))}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">NIK Guru (16 Digit)*</label>
                  <input
                    type="text"
                    required
                    maxLength={16}
                    placeholder="Contoh: 3171011208750001"
                    value={gNik}
                    onChange={(e) => setGNik(e.target.value.replace(/\D/g, ''))}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Nama Lengkap & Gelar*</label>
                  <input
                    type="text"
                    required
                    placeholder="Budi Santoso, S.Pd."
                    value={gNama}
                    onChange={(e) => setGNama(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">NIP (Optional, untuk PNS)*</label>
                  <input
                    type="text"
                    maxLength={18}
                    placeholder="198204152008011003"
                    value={gNip}
                    onChange={(e) => setGNip(e.target.value.replace(/\D/g, ''))}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Sertifikasi Mapel*</label>
                  <input
                    type="text"
                    required
                    placeholder="Matematika / IPA"
                    value={gMapel}
                    onChange={(e) => setGMapel(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Status Pegawai*</label>
                  <select
                    value={gKepegawaian}
                    onChange={(e) => setGKepegawaian(e.target.value as any)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
                  >
                    <option value="PNS">PNS (Aparatur)</option>
                    <option value="PPPK">PPPK Kontrak</option>
                    <option value="GTT">GTT Daerah</option>
                    <option value="HONORER">Honorer Sekolah</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Golongan*</label>
                  <input
                    type="text"
                    required
                    placeholder="III/b atau IX"
                    value={gGolongan}
                    onChange={(e) => setGGolongan(e.target.value)}
                    className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1">Terhitung Mulai Tanggal (TMT) Tugas*</label>
                <input
                  type="date"
                  required
                  value={gTmt}
                  onChange={(e) => setGTmt(e.target.value)}
                  className="block w-full border border-slate-300 rounded px-2.5 py-1.5 focus:outline-none font-mono cursor-pointer"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setGtkModalOpen(false)}
                  className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold cursor-pointer"
                >
                  Simpan GTK
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
