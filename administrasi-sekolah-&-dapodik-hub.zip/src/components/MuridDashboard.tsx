/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { User, PesertaDidik, Rombel, GTK, Pembelajaran, Nilai, Absensi } from '../types';
import { Award, BookOpen, Calendar, HelpCircle, UserCheck, MessageSquare, Bell, Printer, Heart } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import ReportPdf from './ReportPdf';

interface MuridDashboardProps {
  currentUser: User;
  sekolah: any;
  pdList: PesertaDidik[];
  gtkList: GTK[];
  rombelList: Rombel[];
  pembelajaranList: Pembelajaran[];
  nilaiList: Nilai[];
  absensiList: Absensi[];
  onLogout: () => void;
}

export default function MuridDashboard({
  currentUser,
  sekolah,
  pdList,
  gtkList,
  rombelList,
  pembelajaranList,
  nilaiList,
  absensiList,
  onLogout
}: MuridDashboardProps) {

  // Current sub tab
  const [activeTab, setActiveTab] = useState<'NILAI' | 'ABSENSI' | 'JADWAL_PENGUMUMAN'>('NILAI');

  // Find student profile matching the username (NISN)
  const studentProfile = useMemo(() => {
    return pdList.find(p => p.nisn === currentUser.username.trim());
  }, [pdList, currentUser]);

  const student = studentProfile || pdList[0]; // fallback inside sandbox

  // Find class rombel
  const rombel = useMemo(() => {
    return rombelList.find(r => r.id === student.rombel_id);
  }, [rombelList, student]);

  // Find wali kelas profile
  const waliKelas = useMemo(() => {
    if (!rombel) return null;
    return gtkList.find(g => g.id === rombel.wali_kelas_id);
  }, [gtkList, rombel]);

  // Registered class pembelajaran list
  const rombelPembelajaran = useMemo(() => {
    if (!rombel) return [];
    return pembelajaranList.filter(p => p.rombel_id === rombel.id);
  }, [pembelajaranList, rombel]);

  // Grade compilation for charts & list
  const compiledGrades = useMemo(() => {
    return rombelPembelajaran.map(pemb => {
      const grades = nilaiList.filter(n => n.pd_id === student.id && n.pembelajaran_id === pemb.id && n.semester === 1);
      
      const harian = grades.find(g => g.jenis === 'HARIAN')?.nilai_angka || 0;
      const uts = grades.find(g => g.jenis === 'UTS')?.nilai_angka || 0;
      const uas = grades.find(g => g.jenis === 'UAS')?.nilai_angka || 0;
      
      const finalScore = harian && uts && uas 
        ? Math.round((harian * 2 + uts + uas) / 4)
        : harian || uts || uas || 0;

      let letter: 'A' | 'B' | 'C' | 'D' = 'D';
      if (finalScore >= 88) letter = 'A';
      else if (finalScore >= 80) letter = 'B';
      else if (finalScore >= 70) letter = 'C';
      else letter = 'D';

      return {
        subject: pemb.mapel,
        Harian: harian,
        UTS: uts,
        UAS: uas,
        RataRata: finalScore,
        Predikat: letter
      };
    });
  }, [rombelPembelajaran, student, nilaiList]);

  // Overall student GPA / Average
  const averageGpa = useMemo(() => {
    const validScores = compiledGrades.filter(cg => cg.RataRata > 0);
    if (validScores.length === 0) return 0;
    const sum = validScores.reduce((acc, cg) => acc + cg.RataRata, 0);
    return Math.round(sum / validScores.length);
  }, [compiledGrades]);

  // Presence calendar compiling (Absensi counts)
  const presenceRecords = useMemo(() => {
    return absensiList.filter(a => a.pd_id === student.id);
  }, [absensiList, student]);

  const presenceStats = useMemo(() => {
    const total = presenceRecords.length || 1;
    const h = presenceRecords.filter(a => a.status === 'H').length;
    const s = presenceRecords.filter(a => a.status === 'S').length;
    const i = presenceRecords.filter(a => a.status === 'I').length;
    const a = presenceRecords.filter(a => a.status === 'A').length;

    const percentage = Math.round((h / total) * 100);

    return {
      total,
      hadir: h,
      sakit: s,
      izin: i,
      alpa: a,
      percentage: total > 1 ? percentage : 100
    };
  }, [presenceRecords]);

  // Report cards PDF modal
  const [reportModalOpen, setReportModalOpen] = useState(false);

  // Generate simulated June 2026 Calendar dates for the calendar tracker widget!
  const juneCalendarDays = useMemo(() => {
    const days: Array<{ dayNum: number; dateStr: string; status: 'H' | 'S' | 'I' | 'A' | 'HOLIDAY' | 'NONE' }> = [];
    for (let d = 1; d <= 30; d++) {
      const dateStr = `2026-06-${d.toString().padStart(2, '0')}`;
      
      const dayOfWeek = (new Date(2026, 5, d)).getDay(); // 0 is Sunday, 6 is Saturday
      
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        days.push({ dayNum: d, dateStr, status: 'HOLIDAY' });
        continue;
      }

      // Check if attendance records exist
      const record = presenceRecords.find(a => a.tanggal === dateStr);
      if (record) {
        days.push({ dayNum: d, dateStr, status: record.status });
      } else {
        days.push({ dayNum: d, dateStr, status: 'NONE' });
      }
    }
    return days;
  }, [presenceRecords]);

  return (
    <div className="flex flex-col min-h-screen bg-bg-base font-sans">
      
      {/* Banner / Header */}
      <header className="bg-primary border-b border-white/10 text-white">
        <div className="max-w-6xl mx-auto px-4 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-sans">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent text-primary flex items-center justify-center font-bold text-lg select-none">
              🎓
            </div>
            <div>
              <p className="text-[10px] text-accent font-bold uppercase tracking-wider">Dashboard Portal Siswa</p>
              <h2 className="text-md font-extrabold text-white uppercase leading-none mt-0.5">{student.nama}</h2>
              <p className="text-[10px] text-white/80 font-mono mt-1">NISN: {student.nisn} | Kelas: {rombel?.nama || '-'}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 font-sans">
            <span className="inline-flex items-center gap-1 bg-white/10 border border-white/10 px-2.5 py-1 rounded text-xs text-white">
              🏫 Wali Kelas: <strong className="font-semibold text-white">{waliKelas ? waliKelas.nama.split(',')[0] : 'Umar Sahid'}</strong>
            </span>
            <button
              onClick={onLogout}
              className="px-3.5 py-1.5 bg-red-800 hover:bg-red-900 border border-red-700 text-white rounded-lg text-xs font-semibold select-none cursor-pointer transition-all"
            >
              Keluar
            </button>
          </div>
        </div>
      </header>

      {/* Main Board */}
      <main className="max-w-6xl mx-auto px-4 py-6 flex-1 w-full flex flex-col gap-6">
        
        {/* Row of status grids */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4" id="murid-status-overview">
          
          <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex items-center justify-between">
            <div>
              <p className="text-text-muted text-[10px] uppercase font-bold tracking-wider">Nilai Rata-Rata Kamu</p>
              <h3 className="text-2xl font-black text-primary mt-1">{averageGpa} <span className="text-xs font-normal text-text-muted">Skor Akademik</span></h3>
            </div>
            <div className="p-3 bg-accent text-primary rounded-xl">
              <Award className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex items-center justify-between">
            <div>
              <p className="text-text-muted text-[10px] uppercase font-bold tracking-wider">Persentase Keberadaan</p>
              <h3 className="text-2xl font-black text-emerald-800 mt-1">{presenceStats.percentage}% <span className="text-xs font-normal text-text-muted">Tingkat Hadir</span></h3>
            </div>
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <UserCheck className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex items-center justify-between bg-accent/30">
            <div>
              <p className="text-primary text-[10px] uppercase font-bold tracking-wider">Kurikulum Sekolah</p>
              <h3 className="text-sm font-extrabold text-primary mt-1.5">
                {rombel?.kurikulum === 'KURIKULUM_MERDEKA' ? '✨ Kurikulum Merdeka Belajar' : 'K-13 Nasional'}
              </h3>
            </div>
          </div>

        </section>

        {/* Localized Tabs */}
        <section className="flex border-b border-border">
          <button
            onClick={() => setActiveTab('NILAI')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeTab === 'NILAI' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            📊 Evaluasi Hasil Belajar & Grafik Mapel
          </button>
          
          <button
            onClick={() => setActiveTab('ABSENSI')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeTab === 'ABSENSI' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            📅 Kalender Kehadiran
          </button>

          <button
            onClick={() => setActiveTab('JADWAL_PENGUMUMAN')}
            className={`px-4 py-2.5 text-xs font-bold uppercase cursor-pointer border-b-2 transition-all ${
              activeTab === 'JADWAL_PENGUMUMAN' ? 'border-primary text-primary font-bold' : 'border-transparent text-text-muted hover:text-text-main hover:border-border'
            }`}
          >
            🔔 Jadwal Belajar & Pengumuman SMP Negeri 1
          </button>
        </section>

        {/* TAB 1: INDIVIDUAL GRADES & CHART */}
        {activeTab === 'NILAI' && (
          <div className="space-y-6">
            
            {/* Top triggers */}
            <div className="bg-white p-4 rounded-xl border border-slate-180 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h4 className="font-bold text-slate-808 text-sm">Transkrip Nilai Akademik digital</h4>
                <p className="text-[11px] text-slate-500">Nilai hasil evaluasi UTS, UAS, dan tugas Harian semester ganjil.</p>
              </div>
              <button
                onClick={() => setReportModalOpen(true)}
                className="inline-flex items-center gap-2 px-5 py-2 bg-primary hover:bg-primary-hover text-white rounded-lg text-xs font-bold shadow-sm transition-colors cursor-pointer"
                type="button"
              >
                <Printer className="w-4 h-4" />
                Cetak Rapor Digital (Download PDF)
              </button>
            </div>

            {/* Main grid section (Table vs Chart) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Table section */}
              <div className="bg-white rounded-xl border border-border shadow-sm overflow-hidden flex flex-col">
                <div className="px-4 py-3 bg-primary border-b border-white/10">
                  <h4 className="font-bold text-white text-xs uppercase tracking-wider font-sans">Transkrip Detail Mapel</h4>
                </div>
                <div className="flex-1 overflow-x-auto text-xs text-text-main">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#F8FAFC] uppercase text-[10px] font-bold text-text-muted border-b border-border font-mono">
                      <tr>
                        <th className="p-3">Mata Pelajaran</th>
                        <th className="p-3 text-center">Harian</th>
                        <th className="p-3 text-center">UTS</th>
                        <th className="p-3 text-center">UAS</th>
                        <th className="p-3 text-center bg-accent/40 font-bold text-primary">Rata-Rata</th>
                        <th className="p-3 text-center bg-accent/40">Predikat</th>
                      </tr>
                    </thead>
                    <tbody>
                      {compiledGrades.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-4 text-center text-slate-400 italic">Belum ada mata pelajaran terdaftar.</td>
                        </tr>
                      ) : (
                        compiledGrades.map((cg, i) => (
                          <tr key={i} className="border-b border-border hover:bg-accent/40 font-sans">
                            <td className="p-3 font-bold text-text-main">{cg.subject}</td>
                            <td className="p-3 text-center font-mono text-text-main">{cg.Harian || '-'}</td>
                            <td className="p-3 text-center font-mono text-text-main">{cg.UTS || '-'}</td>
                            <td className="p-3 text-center font-mono text-text-main">{cg.UAS || '-'}</td>
                            <td className="p-3 text-center font-bold text-primary bg-accent/20 font-mono">{cg.RataRata || '-'}</td>
                            <td className="p-3 text-center font-black bg-accent/25">
                              <span className={`px-2 py-0.5 rounded text-xs ${
                                cg.Predikat === 'A' ? 'bg-emerald-50 text-emerald-700' :
                                cg.Predikat === 'B' ? 'bg-accent text-primary' :
                                cg.Predikat === 'C' ? 'bg-amber-50 text-amber-700' :
                                'bg-rose-50 text-rose-700'
                              }`}>
                                {cg.Predikat || '-'}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Chart section */}
              <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex flex-col justify-between">
                <h4 className="font-bold text-text-main text-xs uppercase tracking-wider mb-4 border-l-4 border-primary pl-2 font-sans">
                  Grafik Recharts Penilaian Per Mata Pelajaran
                </h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={compiledGrades}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="subject" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="Harian" fill="#94A3B8" name="Tugas Harian" />
                      <Bar dataKey="UTS" fill="#64748B" name="Skor UTS" />
                      <Bar dataKey="UAS" fill="#475569" name="Skor UAS" />
                      <Bar dataKey="RataRata" fill="#0F172A" name="Skor Akhir Rapor" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: DETAILED PRESENCE & JUN-2026 CALENDAR */}
        {activeTab === 'ABSENSI' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Visual calendar block */}
            <div className="bg-white p-5 rounded-xl border border-border shadow-sm lg:col-span-2">
              <h4 className="font-bold text-text-main text-xs uppercase tracking-wider mb-4 border-l-4 border-primary pl-2 font-sans">
                Visual Kalender Kehadiran Sekolah (Juni 2026)
              </h4>

              {/* Days Grid */}
              <div className="grid grid-cols-7 gap-2 text-center text-xs text-text-muted font-medium font-sans">
                {["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map(d => (
                  <div key={d} className="p-1 border-b border-border font-mono text-[10px] tracking-wider uppercase">{d}</div>
                ))}

                {/* June 2026 starts on Monday! So we don't need padding for previous month */}
                {juneCalendarDays.map(day => {
                  let cellClass = "bg-slate-50 text-slate-400 border border-slate-200 animate-fade-in";
                  let statusLabel = "";

                  if (day.status === 'H') {
                    cellClass = "bg-emerald-50 text-emerald-800 border-emerald-300 font-bold";
                    statusLabel = "H";
                  } else if (day.status === 'S') {
                    cellClass = "bg-amber-50 text-amber-800 border-amber-300 font-bold";
                    statusLabel = "S";
                  } else if (day.status === 'I') {
                    cellClass = "bg-accent text-primary border-primary/20 font-bold";
                    statusLabel = "I";
                  } else if (day.status === 'A') {
                    cellClass = "bg-rose-50 text-rose-800 border-rose-300 font-bold";
                    statusLabel = "A";
                  } else if (day.status === 'HOLIDAY') {
                    cellClass = "bg-[#F1F5F9]/60 text-slate-400 pointer-events-none select-none font-normal";
                    statusLabel = "Libur";
                  }

                  return (
                    <div 
                      key={day.dayNum} 
                      className={`p-3.5 rounded-lg flex flex-col items-center justify-between h-14 ${cellClass}`}
                      title={`${day.dateStr} - ${day.status}`}
                    >
                      <span className="text-[10px] text-slate-500 flex-shrink-0 font-mono">{day.dayNum}</span>
                      {statusLabel && <span className="text-[8px] font-black uppercase tracking-wider">{statusLabel}</span>}
                    </div>
                  );
                })}
              </div>

              {/* Calendar Labels */}
              <div className="mt-4 flex gap-4 text-[10.5px] items-center justify-center p-2 border-t border-border font-sans">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-emerald-100 border border-emerald-300 rounded inline-block"></span> Masuk (H)</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-amber-100 border border-amber-300 rounded inline-block"></span> Sakit (S)</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-accent border border-primary/20 rounded inline-block"></span> Izin (I)</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-rose-100 border border-rose-300 rounded inline-block"></span> Alpha (A)</span>
              </div>
            </div>

            {/* Attendance rekap stats widget */}
            <div className="bg-white p-5 rounded-xl border border-border shadow-sm flex flex-col justify-between">
              <div>
                <h4 className="font-bold text-text-main text-xs uppercase tracking-wider mb-4 border-l-4 border-primary pl-2 font-sans">
                  Rekap Frekuensi Presensi S/D Hari Ini
                </h4>
                
                <div className="space-y-4 text-xs mt-6 font-sans">
                  <div className="flex justify-between items-center pb-2 border-b border-dashed border-border text-text-muted">
                    <span>Masa Evaluasi Akademik</span>
                    <strong className="text-text-main font-semibold">Ganjil 2025/2026</strong>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-dashed border-border text-text-muted">
                    <span>Jumlah Sakit (S)</span>
                    <strong className="text-amber-600 font-mono font-bold text-sm bg-amber-50 px-2 py-0.5 rounded border border-amber-200">{presenceStats.sakit} Hari</strong>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-dashed border-border text-text-muted">
                    <span>Jumlah Izin (I)</span>
                    <strong className="text-primary font-mono font-bold text-sm bg-accent px-2 py-0.5 rounded border border-primary/10">{presenceStats.izin} Hari</strong>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-dashed border-border text-text-muted">
                    <span>Jumlah Alpha Tanpa Alasan (A)</span>
                    <strong className="text-rose-600 font-mono font-bold text-sm bg-rose-50 px-2 py-0.5 rounded border border-rose-200">{presenceStats.alpa} Hari</strong>
                  </div>
                  <div className="flex justify-between items-center text-text-muted">
                    <span>Total Hadir Masuk Kelas (H)</span>
                    <span className="text-emerald-700 font-mono font-black text-sm bg-emerald-50 px-2 py-0.5 rounded border border-emerald-250">{presenceStats.hadir} Hari</span>
                  </div>
                </div>
              </div>

              <div className="bg-sky-50 text-sky-900 text-[10px] p-2.5 rounded-lg border border-sky-250 mt-6 leading-relaxed flex items-start gap-1.5 font-serif">
                <Heart className="w-4 h-4 text-sky-600 flex-shrink-0 animate-pulse" />
                <p>Apresiasi Kemdikbud: Pertahankan tingkat kehadiran prima di atas 90% demi menjaga optimalitas belajar serasimu, Nak!</p>
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: SCHEDULES & BULLETIN ANNOUNCEMENTS */}
        {activeTab === 'JADWAL_PENGUMUMAN' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Subject schedule list */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden text-xs text-slate-705">
              <div className="px-4 py-3 bg-slate-900 border-b border-slate-800">
                <h4 className="font-bold text-white text-xs uppercase tracking-wider">Jadwal Kelas Mapel (Semester Ganjil)</h4>
              </div>
              <div className="p-4 space-y-2.5">
                {rombelPembelajaran.length === 0 ? (
                  <p className="text-center text-slate-400 italic">Belum ada mata pelajaran terdaftar.</p>
                ) : (
                  rombelPembelajaran.map(pemb => {
                    const teacher = gtkList.find(g => g.id === pemb.guru_id);
                    return (
                      <div key={pemb.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="p-2 bg-blue-100 text-blue-800 rounded-lg font-bold">🏫</span>
                          <div>
                            <strong className="text-slate-900 block text-sm">{pemb.mapel}</strong>
                            <span className="text-[10px] text-slate-400 block mt-0.5">Guru: {teacher?.nama || 'Guru Mapel'}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="px-2 py-1 rounded bg-blue-50 border border-blue-100 font-bold font-mono text-[10px] uppercase text-blue-700">
                            {pemb.jam_mengajar} JP
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* School bulleting announcement board */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden text-xs text-slate-705">
              <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-500 animate-bounce" />
                <h4 className="font-bold text-white text-xs uppercase tracking-wider">Papan Pengumuman Sekolah SMPN 1</h4>
              </div>
              <div className="p-4 space-y-4 max-h-[360px] overflow-y-auto">
                
                <div className="border-l-4 border-blue-600 pl-3 py-1 bg-slate-50 rounded-r-lg">
                  <span className="text-[9px] text-slate-400 font-mono uppercase font-bold tracking-wider">Diterbitkan: 18 Juni 2026</span>
                  <strong className="text-slate-900 block mt-0.5 text-xs">Pemberitahuan Hari Libur Semester Ganjil</strong>
                  <p className="text-slate-600 text-[11px] leading-relaxed mt-1">
                    Sehubungan dengan selesainya pelaksanaan penginputan nilai Dapodik/EMIS semester ganjil, disampaikan kepada seluruh siswa bahwa libur semester akan dimulai pada 22 Juni 2026 s/d 10 Juli 2026.
                  </p>
                </div>

                <div className="border-l-4 border-amber-600 pl-3 py-1 bg-slate-50 rounded-r-lg">
                  <span className="text-[9px] text-slate-400 font-mono uppercase font-bold tracking-wider">Diterbitkan: 15 Juni 2026</span>
                  <strong className="text-slate-900 block mt-0.5 text-xs">Pengumpulan Tugas Portofolio Informatika</strong>
                  <p className="text-slate-600 text-[11px] leading-relaxed mt-1">
                    Batas akhir unggah tugas portofolio informatika mandiri adalah Sabtu besok ke guru pengampu masing-masing rombel. Bagi siswa yang belum mengumpulkan harap segera melapor.
                  </p>
                </div>

              </div>
            </div>

          </div>
        )}

      </main>

      {/* Rapor Digital Detail Printable Modal view container helper */}
      {reportModalOpen && (
        <ReportPdf
          student={student}
          rombel={rombel!}
          gtkList={gtkList}
          pembelajaranList={pembelajaranList}
          nilaiList={nilaiList}
          absensiList={absensiList}
          semester={1}
          onClose={() => setReportModalOpen(false)}
        />
      )}

    </div>
  );
}
