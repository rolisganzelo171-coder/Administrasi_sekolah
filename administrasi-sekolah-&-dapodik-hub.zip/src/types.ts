/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Role = 'SUPER_ADMIN' | 'OPERATOR_DAPODIK' | 'GURU' | 'MURID';

export interface User {
  id: string;
  username: string; // NISN for MURID, NUPTK/NIP for GURU, initials/names for Admin/Ops
  password_hash: string;
  role: Role;
  is_active: boolean;
  name: string; // Display name
}

export interface Sekolah {
  id: string;
  npsn: string;
  nama: string;
  alamat: string;
  id_kecamatan_dapodik: string;
  tahun_ajaran_aktif: string;
}

export interface PesertaDidik {
  id: string;
  nisn: string; // 10 digits
  nik: string; // 16 digits
  nama: string;
  jk: 'L' | 'P';
  tgl_lahir: string;
  agama: string;
  no_kk: string;
  nama_ayah: string;
  nama_ibu: string;
  alamat: string;
  rombel_id: string; // Reference to Rombel
  status: 'AKTIF' | 'LULUS' | 'MUTASI' | 'KELUAR';
}

export interface GTK {
  id: string;
  nuptk: string | null; // 16 digits
  nik: string; // 16 digits
  nip: string | null; // 18 digits or null
  nama: string;
  mapel_sertifikasi: string;
  status_kepegawaian: 'PNS' | 'PPPK' | 'GTT' | 'HONORER';
  golongan: string; // e.g. IV/a, III/b, etc.
  tmt: string; // Terhitung Mulai Tanggal
  user_id: string; // Ref to User table
}

export interface Rombel {
  id: string;
  nama: string; // Kelas 7-A, 7-B, 8-A, etc.
  tingkat: number; // 7, 8, 9
  kurikulum: 'KURIKULUM_MERDEKA' | 'K13';
  wali_kelas_id: string; // Ref to GTK list
  tahun_ajaran: string;
}

export interface Pembelajaran {
  id: string;
  guru_id: string; // Ref to GTK list
  rombel_id: string; // Ref to Rombel list
  mapel: string; // e.g. Matematika, IPA, Bahasa Indonesia, dsb
  jam_mengajar: number; // e.g. 4 JP
}

export interface Nilai {
  id: string;
  pd_id: string; // Ref to PesertaDidik
  pembelajaran_id: string; // Ref to Pembelajaran
  jenis: 'UTS' | 'UAS' | 'HARIAN';
  nilai_angka: number;
  nilai_huruf: 'A' | 'B' | 'C' | 'D';
  semester: number; // 1 or 2
}

export interface Absensi {
  id: string;
  pd_id: string; // Ref to PesertaDidik
  tanggal: string; // YYYY-MM-DD
  status: 'H' | 'S' | 'I' | 'A'; // Hadir, Sakit, Izin, Alpa
  keterangan: string;
}

export interface JurnalMengajar {
  id: string;
  guru_id: string; // Ref to GTK list
  tanggal: string;
  materi: string;
  metode: string;
  jam_ke: number;
  // Field EMIS GTK tambahan:
  media: string;
  penilaian: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  username: string; // for easier UI reading
  aksi: 'CREATE' | 'UPDATE' | 'DELETE' | 'SYNC_DAPODIK' | 'IMPORT_DAPODIK' | 'EXPORT_DAPODIK';
  tabel: string;
  record_id: string;
  old_data: string | null; // JSON String
  new_data: string | null; // JSON String
  created_at: string; // Timestamp
}

export interface ValidationError {
  id: string;
  tabel: 'PESERTA_DIDIK' | 'GTK';
  record_id: string;
  record_name: string;
  jenis_kesalahan: 'NISN_DUPLIKAT' | 'NIK_KOSONG' | 'NIK_INVALID' | 'NISN_INVALID' | 'NUPTK_INVALID' | 'NO_ROMBEL';
  deskripsi: string;
}
