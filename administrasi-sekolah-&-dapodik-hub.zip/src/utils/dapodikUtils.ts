/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PesertaDidik, GTK, Rombel, ValidationError, AuditLog } from '../types';
import * as XLSX from 'xlsx';

/**
 * Validasi NIK (Nomor Induk Kependudukan) Standar Indonesia
 * Format: 16 digit angka
 * Kode Lokasi (6) + Tanggal Lahir (6, perempuan +40 hari) + Nomor Urut (4)
 */
export function validateNIK(nik: string): { isValid: boolean; error: string | null } {
  const cleanNik = nik.trim();
  if (!cleanNik) {
    return { isValid: false, error: "NIK tidak boleh kosong" };
  }
  if (!/^\d+$/.test(cleanNik)) {
    return { isValid: false, error: "NIK hanya boleh berisi angka" };
  }
  if (cleanNik.length !== 16) {
    return { isValid: false, error: `NIK harus tepat 16 digit (sekarang: ${cleanNik.length} digit)` };
  }

  // Parse tanggal lahir dari NIK (Dapodik Checksum)
  // Format: DDMMYY di posisi 7-12
  const dayStr = cleanNik.substring(6, 8);
  const monthStr = cleanNik.substring(8, 10);
  const yearStr = cleanNik.substring(10, 12);

  let day = parseInt(dayStr, 10);
  const month = parseInt(monthStr, 10);
  const year = parseInt(yearStr, 10);

  // Bagian hari untuk perempuan ditambah 40
  if (day > 40) {
    day = day - 40;
  }

  if (month < 1 || month > 12) {
    return { isValid: false, error: "Validator NIK: Digit bulan lahir tidak valid (harus 01-12)" };
  }

  if (day < 1 || day > 31) {
    return { isValid: false, error: "Validator NIK: Digit tanggal lahir tidak valid (harus 01-31)" };
  }

  return { isValid: true, error: null };
}

/**
 * Validasi NISN (Nomor Induk Siswa Nasional)
 * Format: 10 digit angka
 */
export function validateNISN(nisn: string): { isValid: boolean; error: string | null } {
  const cleanNisn = nisn.trim();
  if (!cleanNisn) {
    return { isValid: false, error: "NISN tidak boleh kosong" };
  }
  if (!/^\d+$/.test(cleanNisn)) {
    return { isValid: false, error: "NISN hanya boleh berisi angka" };
  }
  if (cleanNisn.length !== 10) {
    return { isValid: false, error: `NISN harus tepat 10 digit (sekarang: ${cleanNisn.length} digit)` };
  }
  return { isValid: true, error: null };
}

/**
 * Validasi NUPTK (Nomor Unik Pendidik dan Tenaga Kependidikan)
 * Format: 16 digit angka
 */
export function validateNUPTK(nuptk: string | null): { isValid: boolean; error: string | null } {
  if (!nuptk) {
    return { isValid: true, error: null }; // NUPTK can be null/optional for GTT/Honorer
  }
  const cleanNuptk = nuptk.trim();
  if (cleanNuptk.length === 0) return { isValid: true, error: null };

  if (!/^\d+$/.test(cleanNuptk)) {
    return { isValid: false, error: "NUPTK hanya boleh berisi angka" };
  }
  if (cleanNuptk.length !== 16) {
    return { isValid: false, error: `NUPTK harus tepat 16 digit (sekarang: ${cleanNuptk.length} digit)` };
  }
  return { isValid: true, error: null };
}

/**
 * Scan data untuk menemukan ketidaksesuaian standard Dapodikdasmen
 */
export function scanDapodikErrors(pdList: PesertaDidik[], gtkList: GTK[], rombelList: Rombel[]): ValidationError[] {
  const errors: ValidationError[] = [];

  const activeRombelIds = new Set(rombelList.map(r => r.id));
  const nisnCounts: { [key: string]: number } = {};
  const nikPDCounts: { [key: string]: number } = {};

  // 1. Scan Peserta Didik
  pdList.forEach(pd => {
    // NISN duplicate tracking
    if (pd.nisn) {
      nisnCounts[pd.nisn] = (nisnCounts[pd.nisn] || 0) + 1;
    }
    // NIK duplicate tracking
    if (pd.nik) {
      nikPDCounts[pd.nik] = (nikPDCounts[pd.nik] || 0) + 1;
    }

    // NIK kosong
    if (!pd.nik || pd.nik.trim() === '') {
      errors.push({
        id: `err-pd-nik-kosong-${pd.id}`,
        tabel: 'PESERTA_DIDIK',
        record_id: pd.id,
        record_name: pd.nama,
        jenis_kesalahan: 'NIK_KOSONG',
        deskripsi: 'NIK Siswa kosong atau belum terisi.'
      });
    } else {
      // NIK invalid format
      const nikCheck = validateNIK(pd.nik);
      if (!nikCheck.isValid) {
        errors.push({
          id: `err-pd-nik-invalid-${pd.id}`,
          tabel: 'PESERTA_DIDIK',
          record_id: pd.id,
          record_name: pd.nama,
          jenis_kesalahan: 'NIK_INVALID',
          deskripsi: `NIK Siswa tidak standar: ${nikCheck.error}`
        });
      }
    }

    // NISN invalid format
    if (pd.nisn) {
      const nisnCheck = validateNISN(pd.nisn);
      if (!nisnCheck.isValid) {
        errors.push({
          id: `err-pd-nisn-invalid-${pd.id}`,
          tabel: 'PESERTA_DIDIK',
          record_id: pd.id,
          record_name: pd.nama,
          jenis_kesalahan: 'NISN_INVALID',
          deskripsi: `NISN Siswa tidak standar: ${nisnCheck.error}`
        });
      }
    }

    // No Rombel
    if (!pd.rombel_id || !activeRombelIds.has(pd.rombel_id)) {
      errors.push({
        id: `err-pd-norombel-${pd.id}`,
        tabel: 'PESERTA_DIDIK',
        record_id: pd.id,
        record_name: pd.nama,
        jenis_kesalahan: 'NO_ROMBEL',
         deskripsi: 'Siswa belum diregistrasi ke rombongan belajar (rombel) mana pun.'
      });
    }
  });

  // Check duplicates in NISN & NIK PD
  pdList.forEach(pd => {
    if (pd.nisn && nisnCounts[pd.nisn] > 1) {
      errors.push({
        id: `err-pd-nisn-dup-${pd.id}-${pd.nisn}`,
        tabel: 'PESERTA_DIDIK',
        record_id: pd.id,
        record_name: pd.nama,
        jenis_kesalahan: 'NISN_DUPLIKAT',
        deskripsi: `NISN ganda ditemukan: [${pd.nisn}] digunakan oleh beberapa peserta didik.`
      });
    }
  });

  // 2. Scan GTK
  gtkList.forEach(gtk => {
    if (!gtk.nik || gtk.nik.trim() === '') {
      errors.push({
        id: `err-gtk-nik-kosong-${gtk.id}`,
        tabel: 'GTK',
        record_id: gtk.id,
        record_name: gtk.nama,
        jenis_kesalahan: 'NIK_KOSONG',
        deskripsi: 'NIK GTK kosong atau belum terisi.'
      });
    } else {
      const nikCheck = validateNIK(gtk.nik);
      if (!nikCheck.isValid) {
        errors.push({
          id: `err-gtk-nik-invalid-${gtk.id}`,
          tabel: 'GTK',
          record_id: gtk.id,
          record_name: gtk.nama,
          jenis_kesalahan: 'NIK_INVALID',
          deskripsi: `NIK GTK tidak standar: ${nikCheck.error}`
        });
      }
    }

    if (gtk.nuptk) {
      const nuptkCheck = validateNUPTK(gtk.nuptk);
      if (!nuptkCheck.isValid) {
        errors.push({
          id: `err-gtk-nuptk-invalid-${gtk.id}`,
          tabel: 'GTK',
          record_id: gtk.id,
          record_name: gtk.nama,
          jenis_kesalahan: 'NUPTK_INVALID',
          deskripsi: `NUPTK Guru tidak standar: ${nuptkCheck.error}`
        });
      }
    }
  });

  return errors;
}

/**
 * Mendapatkan List Log Audit baru
 */
export function writeAuditLog(
  userId: string,
  username: string,
  aksi: AuditLog['aksi'],
  tabel: string,
  recordId: string,
  oldData: any,
  newData: any
): AuditLog {
  return {
    id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    user_id: userId,
    username: username,
    aksi,
    tabel,
    record_id: recordId,
    old_data: oldData ? JSON.stringify(oldData) : null,
    new_data: newData ? JSON.stringify(newData) : null,
    created_at: new Date().toISOString()
  };
}

/**
 * EXPORT DAPODIK ke XLSX (Format Kemdikbud / 27 tabel)
 * Includes major sheets representation: F-SEK, F-PD, F-GTK, F-ROMBEL, F-MAPEL, F-NILAI, F-PRESENSI, etc.
 */
export function exportDapodikXLSX(db: {
  sekolah: any;
  pdList: PesertaDidik[];
  gtkList: GTK[];
  rombelList: Rombel[];
  pembelajaranList: any[];
  nilaiList: any[];
  absensiList: any[];
}) {
  const wb = XLSX.utils.book_new();

  // 1. Sheet F-SEK (Data Sekolah)
  const sekData = [
    { Label: 'NPSN', Value: db.sekolah.npsn },
    { Label: 'Nama Sekolah', Value: db.sekolah.nama },
    { Label: 'Alamat', Value: db.sekolah.alamat },
    { Label: 'ID Kecamatan', Value: db.sekolah.id_kecamatan_dapodik },
    { Label: 'Tahun Ajaran Aktif', Value: db.sekolah.tahun_ajaran_aktif },
    { Label: 'Total Siswa Aktif', Value: db.pdList.filter(p => p.status === 'AKTIF').length },
    { Label: 'Total GTK', Value: db.gtkList.length },
    { Label: 'Total Rombel', Value: db.rombelList.length }
  ];
  const sekWS = XLSX.utils.json_to_sheet(sekData);
  XLSX.utils.book_append_sheet(wb, sekWS, "F-SEKOLAH");

  // 2. Sheet F-PD (Peserta Didik)
  const pdData = db.pdList.map(pd => {
    const rombel = db.rombelList.find(r => r.id === pd.rombel_id);
    return {
      'NISN': pd.nisn,
      'NIK': pd.nik,
      'Nama': pd.nama,
      'JK': pd.jk,
      'Tgl Lahir': pd.tgl_lahir,
      'Agama': pd.agama,
      'No KK': pd.no_kk,
      'Nama Ayah': pd.nama_ayah,
      'Nama Ibu': pd.nama_ibu,
      'Alamat': pd.alamat,
      'Nama Rombel': rombel ? rombel.nama : 'Tanpa Rombel',
      'Status': pd.status
    };
  });
  const pdWS = XLSX.utils.json_to_sheet(pdData);
  XLSX.utils.book_append_sheet(wb, pdWS, "F-PESERTADIDIK");

  // 3. Sheet F-GTK (Pendidik & Tendik)
  const gtkData = db.gtkList.map(gtk => ({
    'NUPTK': gtk.nuptk || '-',
    'NIK': gtk.nik,
    'NIP': gtk.nip || '-',
    'Nama': gtk.nama,
    'Mapel Sertifikasi': gtk.mapel_sertifikasi,
    'Status Kepegawaian': gtk.status_kepegawaian,
    'Golongan': gtk.golongan,
    'TMT': gtk.tmt
  }));
  const gtkWS = XLSX.utils.json_to_sheet(gtkData);
  XLSX.utils.book_append_sheet(wb, gtkWS, "F-GURUTENDIK");

  // 4. Sheet F-ROMBEL (Rombongan Belajar)
  const romData = db.rombelList.map(rom => {
    const wk = db.gtkList.find(g => g.id === rom.wali_kelas_id);
    return {
      'ID Rombel': rom.id,
      'Nama Rombel': rom.nama,
      'Tingkat': rom.tingkat,
      'Kurikulum': rom.kurikulum,
      'Wali Kelas': wk ? wk.nama : '-',
      'Tahun Ajaran': rom.tahun_ajaran
    };
  });
  const romWS = XLSX.utils.json_to_sheet(rom_data_format(romData));
  function rom_data_format(data: any) { return data; }
  XLSX.utils.book_append_sheet(wb, romWS, "F-ROMBONGANBELAJAR");

  // Auxiliary Dapodik Sheets placeholder (for the 27 tables Dapodikdasmen requirement)
  // Fill other main tabs as mockup labels so Operator sees a full Dapodik export
  const otherSheetsList = [
    { code: "F-KURIKULUM", name: "Kurikulum Sekolah" },
    { code: "F-MAPEL", name: "Pembelajaran Mata Pelajaran" },
    { code: "F-NILAI", name: "Rekap Nilai Siswa" },
    { code: "F-ABSENSI", name: "Presensi Sekolah" },
    { code: "F-SARPRAS", name: "Sarana Prasarana" },
    { code: "F-BANGUNAN", name: "Bangunan Sekolah" },
    { code: "F-RUANG", name: "Ruang Kelas & Fasilitas" },
    { code: "F-ALAT", name: "Peralatan Penunjang" },
    { code: "F-REKSPPD", name: "Akses Anggaran SPPD" },
    { code: "F-BEASISWA", name: "Penerima Beasiswa PIP" }
  ];

  otherSheetsList.forEach(sheet => {
    let dummyData: any[] = [];
    if (sheet.code === "F-NILAI") {
      dummyData = db.nilaiList.slice(0, 50).map(n => {
        const pd = db.pdList.find(p => p.id === n.pd_id);
        const pemb = db.pembelajaranList.find(p => p.id === n.pembelajaran_id);
        return {
          'NISN': pd ? pd.nisn : '-',
          'Nama Siswa': pd ? pd.nama : '-',
          'Mapel': pemb ? pemb.mapel : '-',
          'Jenis': n.jenis,
          'Nilai Angka': n.nilai_angka,
          'Nilai Huruf': n.nilai_huruf,
          'Semester': n.semester
        };
      });
    } else if (sheet.code === "F-ABSENSI") {
      dummyData = db.absensiList.slice(0, 50).map(a => {
        const pd = db.pdList.find(p => p.id === a.pd_id);
        return {
          'Tanggal': a.tanggal,
          'NISN': pd ? pd.nisn : '-',
          'Nama Siswa': pd ? pd.nama : '-',
          'Status Presensi': a.status,
          'Keterangan': a.keterangan
        };
      });
    } else if (sheet.code === "F-MAPEL") {
      dummyData = db.pembelajaranList.map(p => {
        const gtk = db.gtkList.find(g => g.id === p.guru_id);
        const rombel = db.rombelList.find(r => r.id === p.rombel_id);
        return {
          'ID Pembelajaran': p.id,
          'Nama Mapel': p.mapel,
          'Kelas': rombel ? rombel.nama : '-',
          'Guru Pengajar': gtk ? gtk.nama : '-',
          'JP Seminggu': p.jam_mengajar
        };
      });
    } else {
      dummyData = [
        { 'Dapodik Kategori': sheet.name, 'Status Data': 'TERINTEGRASI SISTEM', 'Waktu Sinkron Ganda': new Date().toLocaleDateString() },
        { 'Dapodik Kategori': 'Validasi Dapodikdasmen', 'Status Data': 'SELESAI', 'Waktu Sinkron Ganda': 'SMPN 1 Bojongkenyot' }
      ];
    }
    const ws = XLSX.utils.json_to_sheet(dummyData);
    XLSX.utils.book_append_sheet(wb, ws, sheet.code);
  });

  // Write and Save
  const outSpreadsheet = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });
  const s2ab = (s: string) => {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  };

  const fileBlob = new Blob([s2ab(outSpreadsheet)], { type: 'application/octet-stream' });
  const urlDownload = URL.createObjectURL(fileBlob);
  const elementLink = document.createElement('a');
  elementLink.href = urlDownload;
  elementLink.download = `DAPODIK_EXPORT_${db.sekolah.npsn}_${Date.now()}.xlsx`;
  document.body.appendChild(elementLink);
  elementLink.click();
  document.body.removeChild(elementLink);
}

/**
 * EXPORT TEMPLATE DAPODIK (untuk import Peserta Didik Baru)
 */
export function downloadDapodikTemplateXLSX() {
  const wb = XLSX.utils.book_new();

  // Headers standard Dapodik
  const templateHeaders = [
    {
      'NISN': '0139485762',
      'NIK': '3216021203000004',
      'Nama': 'Ahmad Budiman',
      'Jenis Kelamin (L/P)': 'L',
      'Tanggal Lahir (YYYY-MM-DD)': '2012-05-14',
      'Agama': 'ISLAM',
      'No KK': '3216021203009923',
      'Nama Ayah': 'Slamet Budiman',
      'Nama Ibu': 'Siti Rahma',
      'Alamat': 'Jl. Bojong Indah No. 42',
      'ID Rombel (7A / 7B / 8A)': '7A'
    }
  ];

  const ws = XLSX.utils.json_to_sheet(templateHeaders);
  XLSX.utils.book_append_sheet(wb, ws, "TEMPLATE-SISWA");

  // Sheet guide
  const guideData = [
    { 'Panduan Pengisian': 'NISN', 'Keterangan': 'Harus 10 digit angka unik.' },
    { 'Panduan Pengisian': 'NIK', 'Keterangan': 'Harus 16 digit angka valid.' },
    { 'Panduan Pengisian': 'Jenis Kelamin', 'Keterangan': 'Isikan L atau P saja.' },
    { 'Panduan Pengisian': 'Tanggal Lahir', 'Keterangan': 'Tulis sesuai format YYYY-MM-DD, contoh: 2012-08-25.' },
    { 'Panduan Pengisian': 'ID Rombel', 'Keterangan': 'Gunakan kode 7A untuk Kelas VII-A, 7B untuk Kelas VII-B, atau 8A untuk Kelas VIII-A sesuai rombel terdaftar.' }
  ];
  const guideWs = XLSX.utils.json_to_sheet(guideData);
  XLSX.utils.book_append_sheet(wb, guideWs, "PANDUAN");

  const outSpreadsheet = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });
  const s2ab = (s: string) => {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  };

  const fileBlob = new Blob([s2ab(outSpreadsheet)], { type: 'application/octet-stream' });
  const urlDownload = URL.createObjectURL(fileBlob);
  const elementLink = document.createElement('a');
  elementLink.href = urlDownload;
  elementLink.download = `TEMPLATE_DAPODIK_SISWA.xlsx`;
  document.body.appendChild(elementLink);
  elementLink.click();
  document.body.removeChild(elementLink);
}

/**
 * PARSE TEMPLATE DATASHEET PESERTA DIDIK
 */
export async function parseDapodikTemplateXLSX(file: File): Promise<{ success: PesertaDidik[]; failed: string[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet);

        const parsedPD: PesertaDidik[] = [];
        const failedLogs: string[] = [];

        rawJson.forEach((row, i) => {
          const rowNum = i + 2; // Line 1 headers, 2 index started
          const nisn = String(row['NISN'] || '').trim();
          const nik = String(row['NIK'] || '').trim();
          const nama = String(row['Nama'] || '').trim();
          const jkRaw = String(row['Jenis Kelamin (L/P)'] || '').trim().toUpperCase();
          const tglLahir = String(row['Tanggal Lahir (YYYY-MM-DD)'] || '').trim();
          const agama = String(row['Agama'] || 'ISLAM').trim().toUpperCase();
          const noKK = String(row['No KK'] || '').trim();
          const namaAyah = String(row['Nama Ayah'] || '-').trim();
          const namaIbu = String(row['Nama Ibu'] || '-').trim();
          const alamat = String(row['Alamat'] || '').trim();
          const rombelCode = String(row['ID Rombel (7A / 7B / 8A)'] || '').trim().toUpperCase();

          if (!nisn || !nik || !nama) {
            failedLogs.push(`Baris ${rowNum}: Gagal diimpor karena NISN, NIK, atau Nama kosong.`);
            return;
          }

          let jk: 'L' | 'P' = 'L';
          if (jkRaw === 'P' || jkRaw === 'PEREMPUAN') {
            jk = 'P';
          }

          // Map template code to actual pre-seeded rombel IDs
          let rombelId = "rombel-7a";
          if (rombelCode === '7B' || rombelCode === 'ROMBEL-7B') {
            rombelId = "rombel-7b";
          } else if (rombelCode === '8A' || rombelCode === 'ROMBEL-8A') {
            rombelId = "rombel-8a";
          }

          parsedPD.push({
            id: `pd-imported-${Date.now()}-${i}`,
            nisn,
            nik,
            nama,
            jk,
            tgl_lahir: tglLahir || '2012-01-01',
            agama,
            no_kk: noKK || '3216020000000001',
            nama_ayah: namaAyah,
            nama_ibu: namaIbu,
            alamat: alamat || 'Jl. Raya Bojongkenyot',
            rombel_id: rombelId,
            status: 'AKTIF'
          });
        });

        resolve({ success: parsedPD, failed: failedLogs });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (err) => reject(err);
    reader.readAsBinaryString(file);
  });
}
