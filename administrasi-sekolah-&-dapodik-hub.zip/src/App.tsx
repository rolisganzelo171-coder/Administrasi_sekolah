/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { User } from './types';
import { getStoredData, saveStoredData, getInitialSeedData } from './data/seed';
import Login from './components/Login';
import OperatorDashboard from './components/OperatorDashboard';
import GuruDashboard from './components/GuruDashboard';
import MuridDashboard from './components/MuridDashboard';
import { ShieldAlert, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [db, setDb] = useState<any>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Load standard seeded Database on mount
  useEffect(() => {
    const loaded = getStoredData();
    setDb(loaded);
  }, []);

  // Update Database state and sync with browser LocalStorage memory
  const handleUpdateDb = (updatedFields: Partial<any>) => {
    setDb((prev: any) => {
      const next = { ...prev, ...updatedFields };
      saveStoredData(next);
      return next;
    });
  };

  // Direct option for developer testing to reset seed database in 1 click
  const handleResetSeedDatabase = () => {
    const confirm = window.confirm("Apakah Anda yakin ingin mengatur ulang (Reset) database sekolah ke kondisi awal (SMPN 1 Bojongkenyot, 1 Kepsek, 2 Operator, 5 Guru, 3 Rombel & 90 Murid)? Semua editan atau nilai terinput baru Anda akan dihapus.");
    if (!confirm) return;

    const freshSeed = getInitialSeedData();
    saveStoredData(freshSeed);
    setDb(freshSeed);
    setCurrentUser(null);
    alert("✓ Database Dapodikberhasil di-reset ke kondisi awal!");
  };

  if (!db) {
    return (
      <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-center p-4">
        <div className="flex items-center gap-2 text-blue-900 font-bold p-3 bg-white rounded-lg shadow-sm border border-slate-205">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span>Sedang memuat Database Dapodikdasmen...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-slate-50">
      
      {/* Floating Developer Sandbox Toolbar (hidden during printing) */}
      <div className="fixed bottom-3 right-3 z-40 bg-white border border-slate-300 p-2.5 rounded-xl shadow-lg flex items-center gap-2 print:hidden text-[10.5px] font-sans hover:border-blue-400 transition-colors">
        <div className="flex items-center gap-1 text-blue-800 font-bold">
          <Layers className="w-3.5 h-3.5" />
          <span>Dapodik Sandbox Engine</span>
        </div>
        <span className="text-slate-300">|</span>
        <button
          onClick={handleResetSeedDatabase}
          className="text-amber-700 hover:text-amber-900 font-bold bg-amber-50 hover:bg-amber-100 px-2 py-1 rounded border border-amber-200 transition-colors cursor-pointer"
          title="Kembalikan Database ke 90 Siswa Bawaan"
        >
          Reset Database Seed (90 Siswa)
        </button>
      </div>

      {/* CORE PORTAL ROUTING BASED ON SESSION ROLE */}
      {!currentUser ? (
        <Login
          users={db.users}
          students={db.pdList}
          teachers={db.gtkList}
          onLoginSuccess={(user) => setCurrentUser(user)}
        />
      ) : (
        <>
          {/* 1. OPERATOR & SUPER ADMIN DASHBOARD */}
          {(currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OPERATOR_DAPODIK') && (
            <OperatorDashboard
              currentUser={currentUser}
              sekolah={db.sekolah}
              pdList={db.pdList}
              gtkList={db.gtkList}
              rombelList={db.rombelList}
              pembelajaranList={db.pembelajaranList}
              nilaiList={db.nilaiList}
              absensiList={db.absensiList}
              auditLogs={db.auditLogs}
              onUpdateDb={handleUpdateDb}
              onLogout={() => setCurrentUser(null)}
            />
          )}

          {/* 2. GURU (TEACHER) DASHBOARD */}
          {currentUser.role === 'GURU' && (
            <GuruDashboard
              currentUser={currentUser}
              sekolah={db.sekolah}
              pdList={db.pdList}
              gtkList={db.gtkList}
              rombelList={db.rombelList}
              pembelajaranList={db.pembelajaranList}
              nilaiList={db.nilaiList}
              absensiList={db.absensiList}
              jurnalList={db.jurnalList || []}
              onUpdateDb={handleUpdateDb}
              onLogout={() => setCurrentUser(null)}
            />
          )}

          {/* 3. MURID (STUDENT) DASHBOARD */}
          {currentUser.role === 'MURID' && (
            <MuridDashboard
              currentUser={currentUser}
              sekolah={db.sekolah}
              pdList={db.pdList}
              gtkList={db.gtkList}
              rombelList={db.rombelList}
              pembelajaranList={db.pembelajaranList}
              nilaiList={db.nilaiList}
              absensiList={db.absensiList}
              onLogout={() => setCurrentUser(null)}
            />
          )}
        </>
      )}

    </div>
  );
}
