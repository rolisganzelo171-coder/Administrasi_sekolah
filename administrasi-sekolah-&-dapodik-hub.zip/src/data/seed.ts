/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sekolah, User, GTK, Rombel, Pembelajaran, PesertaDidik, JurnalMengajar, Nilai, Absensi, AuditLog } from '../types';

// Helper to generate checksum-valid NIK and NISN for seed logic
export function generateNIK(index: number, province: string = "31", regency: string = "71", district: string = "01"): string {
  // NIK format: 16 digits
  // PP.KK.CC.DDMMYY.UUUU
  const birthDatePart = (210000 + (index % 28) + 1).toString(); // DDMMYY approximation
  const counterPart = (1000 + index).toString().substring(1);
  return `${province}${regency}${district}12${birthDatePart}${counterPart}`;
}

export function generateNISN(index: number): string {
  // NISN format: 10 digits
  // e.g., 0123456789
  const prefix = (index % 2 === 0 ? "012" : "013");
  const counter = (1000000 + index).toString().substring(1);
  return `${prefix}${counter}`;
}

const INDONESIAN_FIRST_NAMES = [
  "Abimanyu", "Aditya", "Agung", "Ahmad", "Ananda", "Andika", "Aris", "Aulia", "Bagus", "Bayu",
  "Bintang", "Cahyo", "Daffa", "Dani", "Dewi", "Dimas", "Dwi", "Eka", "Fahri", "Faisal",
  "Farhan", "Fitri", "Galih", "Gilang", "Gita", "Hafiz", "Hana", "Hendra", "Indra", "Intan",
  "Joko", "Kartika", "Kurniawan", "Laras", "Lutfi", "Mega", "Nabila", "Naufal", "Novi", "Putra",
  "Putri", "Rama", "Rehan", "Rian", "Rini", "Rizky", "Santi", "Siti", "Taufik", "Wahyu",
  "Wulan", "Yuda", "Yuli", "Yusuf", "Zacky", "Aisyah", "Amalia", "Anisa", "Arya", "Bambang"
];

const INDONESIAN_LAST_NAMES = [
  "Saputra", "Wibowo", "Pratama", "Hidayat", "Santoso", "Sari", "Lestari", "Kusuma", "Wijaya", "Siregar",
  "Nasution", "Sembiring", "Harahap", "Ginting", "Fauzi", "Ramadhan", "Nugroho", "Setiawan", "Utomo", "Gunawan",
  "Hadi", "Budiman", "Yuliana", "Pratiwi", "Rahayu", "Kurnia", "Fitriani", "Wulandari", "Mahendra", "Perkasa",
  "Susanti", "Purnama", "Subagyo", "Mulyono", "Sutrisno", "Ariyanto", "Kurniyawan", "Wahyudi", "Nugraha", "Aulia"
];

const RELIGIONS = ["ISLAM", "PROTESTAN", "KATOLIK", "HINDU", "BUDHA", "KONGHUCU"];

export function getInitialSeedData() {
  const sekolah: Sekolah = {
    id: "sekolah-smpn1",
    npsn: "20123456",
    nama: "SMP Negeri 1 Bojongkenyot",
    alamat: "Jl. Raya Pendidikan No. 1, Kecamatan Bojongkenyot, Kabupaten Bekasi",
    id_kecamatan_dapodik: "3171010",
    tahun_ajaran_aktif: "2025/2026 Ganjil"
  };

  // 1 Kepsek, 2 Operator, 5 Guru, 90 Murid User accounts
  // Roles: SUPER_ADMIN, OPERATOR_DAPODIK, GURU, MURID
  const users: User[] = [
    {
      id: "usr-admin",
      username: "admin",
      password_hash: "admin123",
      role: "SUPER_ADMIN",
      is_active: true,
      name: "Super Admin Kemdikbud"
    },
    {
      id: "usr-ops1",
      username: "operator1",
      password_hash: "ops123",
      role: "OPERATOR_DAPODIK",
      is_active: true,
      name: "Andi Wijaya (Operator 1)"
    },
    {
      id: "usr-ops2",
      username: "operator2",
      password_hash: "ops123",
      role: "OPERATOR_DAPODIK",
      is_active: true,
      name: "Rina Kartika (Operator 2)"
    },
    // Kepsek (User)
    {
      id: "usr-kepsek",
      username: "1029384756102938", // NUPTK
      password_hash: "guru123",
      role: "GURU",
      is_active: true,
      name: "Dr. H. Ahmad Fauzi, M.Pd."
    },
    // Guru 2
    {
      id: "usr-guru2",
      username: "2039485761029384",
      password_hash: "guru123",
      role: "GURU",
      is_active: true,
      name: "Budi Santoso, S.Pd."
    },
    // Guru 3
    {
      id: "usr-guru3",
      username: "3049586741203948",
      password_hash: "guru123",
      role: "GURU",
      is_active: true,
      name: "Siti Aminah, S.Pd."
    },
    // Guru 4
    {
      id: "usr-guru4",
      username: "4059687391024857",
      password_hash: "guru123",
      role: "GURU",
      is_active: true,
      name: "Diana Lestari, S.Pd.I."
    },
    // Guru 5
    {
      id: "usr-guru5",
      username: "5029183746192837",
      password_hash: "guru123",
      role: "GURU",
      is_active: true,
      name: "Eko Prasetyo, S.Kom."
    }
  ];

  // GTK list
  const gtkList: GTK[] = [
    {
      id: "gtk-kepsek",
      nuptk: "1029384756102938",
      nik: "3171011208750001",
      nip: "197508122000031002",
      nama: "Dr. H. Ahmad Fauzi, M.Pd.",
      mapel_sertifikasi: "Ilmu Pengetahuan Alam (IPA)",
      status_kepegawaian: "PNS",
      golongan: "IV/b",
      tmt: "2000-03-01",
      user_id: "usr-kepsek"
    },
    {
      id: "gtk-guru2",
      nuptk: "2039485761029384",
      nik: "3171011504820003",
      nip: "198204152008011003",
      nama: "Budi Santoso, S.Pd.",
      mapel_sertifikasi: "Matematika",
      status_kepegawaian: "PNS",
      golongan: "III/c",
      tmt: "2008-01-01",
      user_id: "usr-guru2"
    },
    {
      id: "gtk-guru3",
      nuptk: "3049586741203948",
      nik: "3171016311880002",
      nip: "198811232014022001",
      nama: "Siti Aminah, S.Pd.",
      mapel_sertifikasi: "Bahasa Indonesia",
      status_kepegawaian: "PPPK",
      golongan: "IX",
      tmt: "2014-02-01",
      user_id: "usr-guru3"
    },
    {
      id: "gtk-guru4",
      nuptk: "4059687391024857",
      nik: "3171014501910004",
      nip: "199101052020122005",
      nama: "Diana Lestari, S.Pd.I.",
      mapel_sertifikasi: "Bahasa Inggris",
      status_kepegawaian: "PPPK",
      golongan: "IX",
      tmt: "2020-12-01",
      user_id: "usr-guru4"
    },
    {
      id: "gtk-guru5",
      nuptk: "5029183746192837",
      nik: "3171012108950005",
      nip: null,
      nama: "Eko Prasetyo, S.Kom.",
      mapel_sertifikasi: "Informatika / TIK",
      status_kepegawaian: "GTT",
      golongan: "-",
      tmt: "2021-07-15",
      user_id: "usr-guru5"
    }
  ];

  // 3 Rombel (7A, 7B, 8A)
  const rombelList: Rombel[] = [
    {
      id: "rombel-7a",
      nama: "Kelas VIII-A", // let's use 7-A, 7-B, 8-A as requested (or VIII-A, VII-A, etc. let's name them 7A, 7B, 8A)
      tingkat: 7,
      kurikulum: "KURIKULUM_MERDEKA",
      wali_kelas_id: "gtk-guru2", // Budi Santoso
      tahun_ajaran: "2025/2026"
    },
    {
      id: "rombel-7b",
      nama: "Kelas VII-B",
      tingkat: 7,
      kurikulum: "KURIKULUM_MERDEKA",
      wali_kelas_id: "gtk-guru3", // Siti Aminah
      tahun_ajaran: "2025/2026"
    },
    {
      id: "rombel-8a",
      nama: "Kelas VIII-A",
      tingkat: 8,
      kurikulum: "K13",
      wali_kelas_id: "gtk-guru4", // Diana Lestari
      tahun_ajaran: "2025/2026"
    }
  ];

  // Adjust rombel names for clarity
  rombelList[0].nama = "Kelas VII-A";
  rombelList[1].nama = "Kelas VII-B";
  rombelList[2].nama = "Kelas VIII-A";

  // Pembelajaran (6 assignments across the teachers and classes)
  const pembelajaranList: Pembelajaran[] = [
    { id: "pemb-1", guru_id: "gtk-guru2", rombel_id: "rombel-7a", mapel: "Matematika", jam_mengajar: 5 },
    { id: "pemb-2", guru_id: "gtk-kepsek", rombel_id: "rombel-7a", mapel: "IPA", jam_mengajar: 4 },
    { id: "pemb-3", guru_id: "gtk-guru3", rombel_id: "rombel-7b", mapel: "Bahasa Indonesia", jam_mengajar: 6 },
    { id: "pemb-4", guru_id: "gtk-guru4", rombel_id: "rombel-8a", mapel: "Bahasa Inggris", jam_mengajar: 4 },
    { id: "pemb-5", guru_id: "gtk-guru5", rombel_id: "rombel-8a", mapel: "Informatika", jam_mengajar: 3 },
    { id: "pemb-6", guru_id: "gtk-guru2", rombel_id: "rombel-8a", mapel: "Matematika", jam_mengajar: 5 }
  ];

  // 90 students
  const pdList: PesertaDidik[] = [];
  const rombelKeys = ["rombel-7a", "rombel-7b", "rombel-8a"];

  // Populate exactly 90 students
  for (let i = 1; i <= 90; i++) {
    const rombelId = rombelKeys[(i - 1) % 3]; // cyclic assignment: 30 per rombel
    const firstName = INDONESIAN_FIRST_NAMES[(i * 3 + 7) % INDONESIAN_FIRST_NAMES.length];
    const lastName = INDONESIAN_LAST_NAMES[(i * 2 + 13) % INDONESIAN_LAST_NAMES.length];
    const nama = `${firstName} ${lastName}`;
    const jk = (i % 2 === 0) ? 'L' : 'P';
    const numstr = i.toString().padStart(3, '0');
    
    const nisn = generateNISN(i);
    const nik = generateNIK(i);

    // Let's create an account for 1 student as validation example to login
    // Students can log in using their NISN as username and password "siswa123"
    // To save memory/space, we add user entries for the first student of each class,
    // plus we add all user records dynamically if students log in.
    if (i <= 3) {
      users.push({
        id: `usr-siswa-${i}`,
        username: nisn,
        password_hash: "siswa123",
        role: "MURID",
        is_active: true,
        name: nama
      });
    }

    pdList.push({
      id: `pd-${i}`,
      nisn: nisn,
      nik: nik,
      nama: nama,
      jk: jk,
      tgl_lahir: `2012-04-${(i % 28 + 1).toString().padStart(2, '0')}`,
      agama: RELIGIONS[i % RELIGIONS.length],
      no_kk: `321602120${i.toString().padStart(3, '0')}0001`,
      nama_ayah: `${INDONESIAN_FIRST_NAMES[(i * 5) % INDONESIAN_FIRST_NAMES.length]} ${lastName}`,
      nama_ibu: `${INDONESIAN_FIRST_NAMES[(i * 4 + 2) % INDONESIAN_FIRST_NAMES.length]} Wulandari`,
      alamat: `Kampung Bojongjaya No. ${i}, RT 02/RW 04, Desa Bojongkenyot`,
      rombel_id: rombelId,
      status: "AKTIF"
    });
  }

  // Pre-seed some Grades (Nilai) so the charts and student scores have gorgeous data
  const nilaiList: Nilai[] = [];
  // Generate some scores for student-1, student-2, student-3, and student-4 for visual graphs
  // For PEMBELAJARAN 1 (Matematika di 7A) and PEMBELAJARAN 2 (IPA di 7A)
  // Let's loop the first 10 students (which belong to 7A or other rombels) and pre-seed their grades
  for (let s = 0; s < 15; s++) {
    const student = pdList[s];
    // Find pembelajaran for this student's rombel
    const matchingPemb = pembelajaranList.filter(p => p.rombel_id === student.rombel_id);
    
    matchingPemb.forEach(pemb => {
      // Create harian, uts, uas
      const scores: Array<"HARIAN" | "UTS" | "UAS"> = ["HARIAN", "UTS", "UAS"];
      scores.forEach(jenis => {
        let sc = 75 + ((s * 3 + jenis.length) % 22);
        if (sc > 100) sc = 95;
        
        let gradeChar: 'A' | 'B' | 'C' | 'D' = 'C';
        if (sc >= 88) gradeChar = 'A';
        else if (sc >= 80) gradeChar = 'B';
        else if (sc >= 70) gradeChar = 'C';
        else gradeChar = 'D';

        nilaiList.push({
          id: `nil-${student.id}-${pemb.id}-${jenis}`,
          pd_id: student.id,
          pembelajaran_id: pemb.id,
          jenis: jenis,
          nilai_angka: sc,
          nilai_huruf: gradeChar,
          semester: 1
        });
      });
    });
  }

  // Pre-seed Absensi for a past couple of days for the classes
  const absensiList: Absensi[] = [];
  const dates = ["2026-06-16", "2026-06-17", "2026-06-18"];
  // Randomly set attendance for first 15 students
  for (let s = 0; s < 20; s++) {
    const student = pdList[s];
    dates.forEach((date, dIdx) => {
      // 90% Hadir, occasional Sakit (S), Izin (I), Alpa (A)
      let status: 'H' | 'S' | 'I' | 'A' = 'H';
      let ket = 'Hadir Masuk';
      const r = (s + dIdx * 7) % 20;
      if (r === 18) {
        status = 'S';
        ket = 'Sakit Demam';
      } else if (r === 19) {
        status = 'I';
        ket = 'Izin Urusan Keluarga';
      } else if (r === 0) {
        status = 'A';
        ket = 'Tanpa Keterangan';
      }
      
      absensiList.push({
        id: `abs-${student.id}-${date}`,
        pd_id: student.id,
        tanggal: date,
        status: status,
        keterangan: ket
      });
    });
  }

  // Pre-seed some JurnalMengajar entries
  const jurnalList: JurnalMengajar[] = [
    {
      id: "jur-1",
      guru_id: "gtk-guru2",
      tanggal: "2026-06-17",
      materi: "Aljabar Linear dan Persamaan Satu Variabel",
      metode: "Ceramah Interaktif & Latihan Kelompok",
      jam_ke: 1,
      media: "Papan Tulis & Proyektor",
      penilaian: "Tugas Pengayaan"
    },
    {
      id: "jur-2",
      guru_id: "gtk-guru3",
      tanggal: "2026-06-17",
      materi: "Menulis Teks Prosedur Kompleks",
      metode: "Pembelajaran Berbasis Proyek (PBL)",
      jam_ke: 3,
      media: "Lembar Kerja Siswa & Contoh Buku Prosedur",
      penilaian: "Presentasi Karya Prosedur"
    }
  ];

  // Pre-seed custom audit logs to begin with
  const auditLogs: AuditLog[] = [
    {
      id: "log-1",
      user_id: "usr-admin",
      username: "admin",
      aksi: "CREATE",
      tabel: "Sekolah",
      record_id: "sekolah-smpn1",
      old_data: null,
      new_data: JSON.stringify(sekolah),
      created_at: "2026-06-18T08:00:00.000Z"
    },
    {
      id: "log-2",
      user_id: "usr-ops1",
      username: "operator1",
      aksi: "SYNC_DAPODIK",
      tabel: "Dapodik",
      record_id: "sekolah-smpn1",
      old_data: "{\"last_sync\":\"2026-05-18\"}",
      new_data: "{\"last_sync\":\"2026-06-18\"}",
      created_at: "2026-06-18T09:15:00.000Z"
    }
  ];

  return {
    sekolah,
    users,
    gtkList,
    rombelList,
    pembelajaranList,
    pdList,
    nilaiList,
    absensiList,
    jurnalList,
    auditLogs
  };
}

// Global helper to load data from localStorage or seed
export function getStoredData() {
  const stored = localStorage.getItem('dapodik_db');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.error("Failed to parse stored dapodik_db, re-seeding", e);
    }
  }
  
  // Seed initial data
  const data = getInitialSeedData();
  localStorage.setItem('dapodik_db', JSON.stringify(data));
  return data;
}

export function saveStoredData(data: any) {
  localStorage.setItem('dapodik_db', JSON.stringify(data));
}
